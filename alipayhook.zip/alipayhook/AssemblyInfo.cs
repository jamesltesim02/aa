﻿// Assembly alipayhook, Version 1.0.0.0

[assembly: System.Runtime.CompilerServices.SuppressIldasm]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Runtime.Versioning.TargetFramework(".NETFramework,Version=v4.5.2", FrameworkDisplayName=".NET Framework 4.5.2")]
[assembly: System.Reflection.AssemblyCompany("Microsoft")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyTitle("alipayhook")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9 Microsoft 2019")]
[assembly: System.Reflection.AssemblyProduct("alipayhook")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.InteropServices.Guid("0a8c075a-7941-4298-805a-0dd69b515759")]

