﻿namespace alipayhook
{
    using System;

    public enum LogFile
    {
        Trace,
        Error,
        SQL,
        SQLError,
        Login,
        Info,
        WeChat,
        Market_his_,
        payment_,
        detail_
    }
}

