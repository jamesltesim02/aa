﻿namespace alipayhook
{
    using System;
    using System.Drawing;
    using System.Runtime.InteropServices;

    internal class WinIoUtil
    {
        public const int KBC_KEY_CMD = 100;
        public const int KBC_KEY_DATA = 0x60;
        private const int MOUSEEVENTF_MOVE = 1;
        private const int MOUSEEVENTF_LEFTDOWN = 2;
        private const int MOUSEEVENTF_LEFTUP = 4;
        private const int MOUSEEVENTF_RIGHTDOWN = 8;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;
        private const int MOUSEEVENTF_MIDDLEDOWN = 0x20;
        private const int MOUSEEVENTF_MIDDLEUP = 0x40;
        private const int MOUSEEVENTF_ABSOLUTE = 0x8000;

        static WinIoUtil()
        {
            InfaceMaxtoCode.Startup();
        }

        [DllImport("user32.dll")]
        public static extern void GetCursorPos(ref Point O0l0011);
        [DllImport("winio.dll")]
        public static extern bool GetPhysLong(IntPtr O010lOOO10, byte OO0OlO0Ol1);
        [DllImport("winio.dll")]
        public static extern bool GetPortVal(IntPtr O0OlO1OOO, out int OlO0O1O11l, byte OO001);
        public void Initialize()
        {
        }

        [DllImport("winio.dll")]
        public static extern bool InitializeWinIo();
        public void KeyDown(int OOl011ll)
        {
        }

        public void KeyDownUp(int Oll0O00O)
        {
        }

        public void KeyUp(int OlOOlllO)
        {
        }

        [DllImport("winio.dll")]
        public static extern byte MapPhysToLin(byte OllOl1O101, uint O0l0l0OlO0, IntPtr Ol11l10010OOlO11101O);
        [DllImport("user32.dll")]
        public static extern int MapVirtualKey(uint O1110, uint O1OO1ll0);
        [DllImport("user32.dll")]
        public static extern void mouse_event(int O1Ol1Ol, int Ol, int OO, int O1lO11, int OllOOOll10O);
        public void MyMouseDown(int O00O0Ol1)
        {
        }

        public void MyMouseUp(int O11O00l1)
        {
        }

        private void OOOOO11lOO0()
        {
        }

        [DllImport("user32.dll")]
        public static extern void SetCursorPos(int O0, int O0);
        [DllImport("winio.dll")]
        public static extern bool SetPhysLong(IntPtr OO10O0O0l1, byte O0l0OO011);
        [DllImport("winio.dll")]
        public static extern bool SetPortVal(uint O1O0O01Ol, IntPtr Ol1110l0O, byte OllOl);
        public void Shutdown()
        {
        }

        [DllImport("winio.dll")]
        public static extern void ShutdownWinIo();
        [DllImport("winio.dll")]
        public static extern bool UnmapPhysicalMemory(IntPtr Oll11lO1llOOOlll1010, byte O0ll01000);

        public enum Key
        {
            move = 1,
            leftdown = 2,
            leftup = 4,
            rightdown = 8,
            rightup = 0x10,
            middledown = 0x20,
            VK_LBUTTON = 1,
            VK_RBUTTON = 2,
            VK_CANCEL = 3,
            VK_MBUTTON = 4,
            VK_BACK = 8,
            VK_TAB = 9,
            VK_CLEAR = 12,
            VK_RETURN = 13,
            VK_SHIFT = 0x10,
            VK_CONTROL = 0x11,
            VK_MENU = 0x12,
            VK_PAUSE = 0x13,
            VK_CAPITAL = 20,
            VK_ESCAPE = 0x1b,
            VK_SPACE = 0x20,
            VK_PRIOR = 0x21,
            VK_NEXT = 0x22,
            VK_END = 0x23,
            VK_HOME = 0x24,
            VK_LEFT = 0x25,
            VK_UP = 0x26,
            VK_RIGHT = 0x27,
            VK_DOWN = 40,
            VK_SELECT = 0x29,
            VK_PRINT = 0x2a,
            VK_EXECUTE = 0x2b,
            VK_SNAPSHOT = 0x2c,
            VK_INSERT = 0x2d,
            VK_DELETE = 0x2e,
            VK_HELP = 0x2f,
            VK_NUM0 = 0x30,
            VK_NUM1 = 0x31,
            VK_NUM2 = 50,
            VK_NUM3 = 0x33,
            VK_NUM4 = 0x34,
            VK_NUM5 = 0x35,
            VK_NUM6 = 0x36,
            VK_NUM7 = 0x37,
            VK_NUM8 = 0x38,
            VK_NUM9 = 0x39,
            VK_A = 0x41,
            VK_B = 0x42,
            VK_C = 0x43,
            VK_D = 0x44,
            VK_E = 0x45,
            VK_F = 70,
            VK_G = 0x47,
            VK_H = 0x48,
            VK_I = 0x49,
            VK_J = 0x4a,
            VK_K = 0x4b,
            VK_L = 0x4c,
            VK_M = 0x4d,
            VK_N = 0x4e,
            VK_O = 0x4f,
            VK_P = 80,
            VK_Q = 0x51,
            VK_R = 0x52,
            VK_S = 0x53,
            VK_T = 0x54,
            VK_U = 0x55,
            VK_V = 0x56,
            VK_W = 0x57,
            VK_X = 0x58,
            VK_Y = 0x59,
            VK_Z = 90,
            VK_NUMPAD0 = 0x60,
            VK_NUMPAD1 = 0x61,
            VK_NUMPAD2 = 0x62,
            VK_NUMPAD3 = 0x63,
            VK_NUMPAD4 = 100,
            VK_NUMPAD5 = 0x65,
            VK_NUMPAD6 = 0x66,
            VK_NUMPAD7 = 0x67,
            VK_NUMPAD8 = 0x68,
            VK_NUMPAD9 = 0x69,
            VK_NULTIPLY = 0x6a,
            VK_ADD = 0x6b,
            VK_SEPARATOR = 0x6c,
            VK_SUBTRACT = 0x6d,
            VK_DECIMAL = 110,
            VK_DIVIDE = 0x6f,
            VK_F1 = 0x70,
            VK_F2 = 0x71,
            VK_F3 = 0x72,
            VK_F4 = 0x73,
            VK_F5 = 0x74,
            VK_F6 = 0x75,
            VK_F7 = 0x76,
            VK_F8 = 0x77,
            VK_F9 = 120,
            VK_F10 = 0x79,
            VK_F11 = 0x7a,
            VK_F12 = 0x7b,
            VK_NUMLOCK = 0x90,
            VK_SCROLL = 0x91,
            middleup = 0x40,
            xdown = 0x80,
            xup = 0x100,
            wheel = 0x800,
            virtualdesk = 0x4000,
            absolute = 0x8000
        }
    }
}

