﻿namespace alipayhook
{
    using OpenQA.Selenium;
    using System;
    using System.Runtime.InteropServices;
    using XWebDriver;

    internal class WithdrawBank
    {
        public OneDriver wd;

        static WithdrawBank()
        {
            InfaceMaxtoCode.Startup();
        }

        public WithdrawBank(OneDriver O111000 = null)
        {
        }

        public void fixRandSelectBankName()
        {
        }

        public void inputBankById(string OOlO, string OllllO)
        {
        }

        public void inputBankByName(string OOlO, string O11lO1)
        {
        }

        public void inputReason()
        {
        }

        private void O00Ol1001l1l01Ol0l0O0l()
        {
        }

        private void O1O111ll100OO11O11lOl()
        {
        }

        private void OOOOOl0llOO0Ol111010l0l()
        {
        }

        public void sendKeyByOne(IWebElement O, string OOO0)
        {
        }
    }
}

