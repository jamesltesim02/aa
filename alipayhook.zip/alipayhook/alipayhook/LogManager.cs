﻿namespace alipayhook
{
    using System;
    using System.Text;

    public class LogManager
    {
        private string O11Olll101O;
        private string Ol1O000;
        private string O0O110ll1OO001;
        private bool O100l1OOl1Ol;
        private bool O1lO110OlO00l1O1101lOl;
        private Encoding O0l01111O11110l;
        private object O11;

        static LogManager()
        {
            InfaceMaxtoCode.Startup();
        }

        public LogManager()
        {
        }

        public LogManager(string Ol00OO0, string Ol1O1O01l1ll0O, bool OO01ll1111lO)
        {
        }

        public void WriteLog(string O0l)
        {
            this.WriteLog(string.Empty, O0l);
        }

        public void WriteLog(LogFile OOO1OO0, string O11)
        {
        }

        public void WriteLog(string O0llO11, string O00)
        {
        }

        public string LogPath
        {
            get
            {
            }
            set
            {
            }
        }

        public string LogFileExtName
        {
            get
            {
            }
            set => 
                (this.O0O110ll1OO001 = value);
        }

        public bool WriteLogTime
        {
            get
            {
            }
            set => 
                (this.O100l1OOl1Ol = value);
        }

        public bool LogFileNameEndWithDate
        {
            get
            {
            }
            set => 
                (this.O1lO110OlO00l1O1101lOl = value);
        }

        public Encoding LogFileEncoding
        {
            get
            {
            }
            set => 
                (this.O0l01111O11110l = value);
        }
    }
}

