﻿namespace alipayhook
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Net;
    using System.Net.Security;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Threading;
    using System.Windows.Forms;
    using XWebDriver;

    public class Form1 : Form
    {
        public const int WM_CLOSE = 0x10;
        public const int WM_HIDE = 0;
        public IntPtr myDriverWndIntPtr;
        private const int SW_SHOWNORMAL = 1;
        private const int SW_RESTORE = 9;
        private const int SW_SHOWNOACTIVATE = 4;
        private const int WM_KEYDOWN = 0x100;
        private const int WM_KEYUP = 0x101;
        private const int WM_SYSCHAR = 0x106;
        private const int WM_SYSKEYUP = 0x105;
        private const int WM_SYSKEYDOWN = 260;
        private const int WM_CHAR = 0x102;
        private const int WM_SHOWWINDOW = 0x18;
        public const byte vbKeyRButton = 2;
        public const byte vbKeyCancel = 3;
        public const byte vbKeyMButton = 4;
        public const byte vbKeyBack = 8;
        public const byte vbKeyTab = 9;
        public const byte vbKeyClear = 12;
        public const byte vbKeyReturn = 13;
        public const byte vbKeyShift = 0x10;
        public const byte vbKeyControl = 0x11;
        public const byte vbKeyAlt = 0x12;
        public const byte vbKeyMenu = 0x12;
        public const byte vbKeyPause = 0x13;
        public const byte vbKeyCapital = 20;
        public const byte vbKeyEscape = 0x1b;
        public const byte vbKeySpace = 0x20;
        public const byte vbKeyPageUp = 0x21;
        public const byte vbKeyEnd = 0x23;
        public const byte vbKeyHome = 0x24;
        public const byte vbKeyLeft = 0x25;
        public const byte vbKeyUp = 0x26;
        public const byte vbKeyRight = 0x27;
        public const byte vbKeyDown = 40;
        public const byte vbKeySelect = 0x29;
        public const byte vbKeyPrint = 0x2a;
        public const byte vbKeyExecute = 0x2b;
        public const byte vbKeySnapshot = 0x2c;
        public const byte vbKeyDelete = 0x2e;
        public const byte vbKeyHelp = 0x2f;
        public const byte vbKeyNumlock = 0x90;
        public static string sms_code_url;
        public static string s_cookies;
        public static string DefaultUserAgent;
        public static Dictionary<string, Dictionary<string, string>> login_dic;
        public static OneDriver wd;
        public static string s_uid;
        public static bool login_status;
        public static Thread thread_watch_online;
        public static bool thread_watch_online_quit_flag;
        public static Dictionary<string, Dictionary<string, string>> order_dic;
        public Browsers seleniumDriverType;
        public bool show_window_mode;
        public static Thread thread_report_order;
        public static string page_mode;
        public bool loading_login;
        public Queue<Dictionary<string, string>> q_customer_order;
        public static bool authLoginStatus;
        public static string last_deposit_order_no;
        public static string last_transfer_order_no;
        public static string last_withdraw_order_no;
        public static string notify_url;
        public static string report_url;
        public static string order_url;
        public static int alipay_keep_money;
        public static bool event_selenium_exception;
        private IContainer OlO0O0OllO;
        private Button O1111l1;
        private PictureBox OOlOOOOl0OO;
        private ImageList O0Ol1OlOlO;
        private RichTextBox Ol110O0011O0;
        private Label OlOOl0;
        private Label OO100O;
        private TextBox OllO1ll1l000;
        private TextBox O1100lO11O1;
        private TextBox OllO1lOO01l1;
        private Label O0ll00;
        private PictureBox O11OOO1OlO1;
        private TextBox O001l110l10;
        private Label OlOO10lO0;
        private Button OOOO0ll;
        private GroupBox Olll10011;
        private GroupBox Oll0O0011;
        private Label O0000O;
        private Label O0OOl0;
        private TextBox O10l1Oll1OOlO101OOlO0;
        private TextBox O1OlO1O0110llO00101l;
        private Label O101OlO0llO1l;
        private Button O1llll0;
        private Button OO0O1OlOl010;
        private Button OO1O0ll;
        private GroupBox O000Olll1;
        private Label O01OO0;
        private PictureBox O11l00O011l;
        private Timer OOl0lO;
        private Label Olll1l11ll;
        private Label Oll11OOlO1O;
        private Button OOl10O0;
        private GroupBox O11lOl101;
        private Label O1llO0;
        private Label O00O11;
        private TextBox Ol111O0l0OlOllO;
        private TextBox O1l1O0l11ll001O11;
        private CheckBox O0lO0OO101ll1OOl0;
        private Button O01Oll1;
        private Label O0l10l;
        private TextBox O10O11OllO1Ol01lO101Ol1;
        private Label O00l011;
        private TextBox OOOO00lOlO1OllOl01l0O;
        private Label OO0l00l;
        private TextBox OOOOll001lOlOO1lO11l;
        private Label O1100OO00llOOll1;
        private Label OOO1O0l;
        private ListBox OO0O00l00OlO11000;
        private GroupBox O1Oll100l;
        private Button OO0lO11;
        private Button OO1l1ll;
        private Label O1101100000;
        private Button O0O0O10;
        private RadioButton OO01O0lll01ll11Ol011;
        private RadioButton Ol1110llOl101001ll;

        static Form1()
        {
            InfaceMaxtoCode.Startup();
            old_acctor_mc();
        }

        protected override void Dispose(bool Ol0l0l110)
        {
        }

        [DllImport("user32")]
        public static extern int EnumWindows(CallBack O, int O);
        public void FindWebDriverHideWnd()
        {
        }

        public void FindWebDriverWnd()
        {
        }

        [DllImport("User32.dll")]
        private static extern IntPtr FindWindow(string OOO10000OOO, string O110010l0O01);
        [DllImport("user32.dll")]
        private static extern int GetClassNameW(IntPtr O10O, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder Oll101l1, int OO1Ol0lO0);
        [DllImport("user32.dll")]
        private static extern int GetWindowTextW(IntPtr O0O0, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder OlO110Ol, int OO0OlOO00);
        public bool HideWndcall(int O0l0, int O010O0)
        {
        }

        public HttpWebResponse HttpGet(string OOO, string Ol00l0l = "")
        {
        }

        public HttpWebResponse HttpPost(string Oll, IDictionary<string, string> OllllOOl11, string O1OOl01 = "")
        {
        }

        public static string HttpUrlEncode(string OO1)
        {
        }

        [DllImport("user32.dll")]
        private static extern void keybd_event(byte Ol0, byte OOll1, uint OOO1O01, uint O1l100O00l1);
        public static string MD5Encrypt32(string O1lO1lO)
        {
        }

        [DllImport("user32.dll")]
        private static extern void mouse_event(Oll101O0O01110 O10ll, int Ol, int Ol, uint Ol01, UIntPtr OlOl1l0O0);
        private void O00l01OlO1l0OlOOOO1O()
        {
        }

        private void O01O1O00OOll1()
        {
        }

        private void O0l01OO1l10(object Ol01ll, EventArgs O)
        {
        }

        private void O0l1100OOO1ll0lllOl10110010lO0111(object Ol10lO, EventArgs O)
        {
        }

        private void O0lOlO1lO10lll01lOOlOl010O1lllOO1l1OO0(object OO1010, EventArgs O)
        {
        }

        private void O0O110O10()
        {
        }

        private void O0O110OOO0OO()
        {
        }

        private bool O0OOllOl100OO(ref int OO1llOOl)
        {
        }

        private List<Dictionary<string, string>> O0OOOll1ll00()
        {
        }

        private void O11000OO10001lll()
        {
        }

        private void O110O()
        {
        }

        private void O111l0OlOOO11ll(object O1010l, EventArgs O)
        {
        }

        private void O111l10l0111l(object O11l00, EventArgs O)
        {
        }

        private void O111O01OOl1l1(object OOO1O0, EventArgs O)
        {
        }

        private void O11l100lllOl10Olll1011l100OO1(object Ol00lO, EventArgs O)
        {
            this.OOOlll0l0Ol10O111ll0100(Ol00lO, O);
        }

        private bool O11ll00Ol1l0Ol1O1(ref int Ol11111O)
        {
        }

        private void O1l1Ol0011l1l(object O1l1OO, EventArgs O)
        {
        }

        private void O1O01lO0lOOO0(string Oll10111)
        {
        }

        private void O1O1O101ll1lO(object O01O1O, EventArgs O)
        {
        }

        private void O1Ol0l1OOl1l1Ol10l0()
        {
        }

        private void Ol0O11O0lO11l(object OOl0l0, EventArgs O)
        {
        }

        private bool Ol10ll10(string O1l0OO0lOOO1O0l, string Oll1l10010ll1O)
        {
        }

        private void Ol10Ol0l0Ol0l0l0Ol(object O0l1l1, EventArgs O)
        {
        }

        private void Ol1l1O0O0Ol1l(object O1OlOl, EventArgs O)
        {
        }

        private double Ol1O1O0llllO00O10()
        {
        }

        private static void old_acctor_mc()
        {
        }

        private void OlllO1O(string O10l101O)
        {
        }

        private void OlOl1llOll0Ol(object O0O011, EventArgs O)
        {
        }

        private List<Dictionary<string, string>> OlOO1000O1l000O()
        {
        }

        private void OlOO1OlO01001()
        {
        }

        private void OO00l0O0l10llO01Ol0O0(int O10OlO1l = 1)
        {
        }

        private void OO00ll1lll1O10O1l()
        {
        }

        private void OO0l010OOl(object OOOlOO, EventArgs O)
        {
        }

        private bool OO0l110lOOlllO(string O0ll00000lO, int OOlO1O1O1 = 0)
        {
        }

        private void OO0llOl1llO(object O0OO00, EventArgs O)
        {
        }

        private void OO1l1O000O00O(object OO0lO1, EventArgs O)
        {
        }

        private void OO1ll001lO0O01OO00()
        {
        }

        private void OOl10001(object OOl0OlOO)
        {
        }

        private void OOlO1O011l011()
        {
        }

        private void OOO01000110O0l00l(object O00ll0, EventArgs O)
        {
        }

        private void OOO01O0O()
        {
        }

        private bool OOO1001l11O0O1l0l0OOl(object OOOllO, X509Certificate O1l00lOllO1, X509Chain O110l, SslPolicyErrors Ol01OO)
        {
        }

        private void OOO11011lO100(object Ol00O1, EventArgs O)
        {
        }

        private void OOOlll0l0Ol10O111ll0100(object O10lO0, EventArgs O)
        {
        }

        private List<Dictionary<string, string>> OOOlll10lll01O(int OO1111O01 = 0, int OO00l0O = 1)
        {
        }

        [DllImport("user32.dll", EntryPoint="PostMessageA")]
        public static extern int PostMessage(IntPtr OOOl, int OO1O, int OOl0l0, int OOOlOO);
        public bool Recall(int Ol11, int OOl0l1)
        {
        }

        public static string RunCmd(string O001000)
        {
        }

        [DllImport("user32.dll", EntryPoint="SendMessageA")]
        public static extern int SendMessage(IntPtr Ol10, int O1OO, int OOO0lO, int OOO0O0);
        public void SendWebDriverInputStr(IntPtr Ol, string O1l11)
        {
        }

        [DllImport("user32.dll")]
        private static extern IntPtr SetActiveWindow(IntPtr OO1O);
        [DllImport("user32.dll")]
        private static extern int SetCursorPos(int O, int O);
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr O00l);
        [DllImport("user32.dll", CharSet=CharSet.Auto)]
        public static extern int ShowWindow(IntPtr OOl0, int OOOl10O1);

        public delegate bool CallBack(int O011, int Ol1001);

        [Flags]
        private enum Oll101O0O01110 : uint
        {
            Move = 1,
            LeftDown = 2,
            LeftUp = 4,
            RightDown = 8,
            RightUp = 0x10,
            MiddleDown = 0x20,
            MiddleUp = 0x40,
            XDown = 0x80,
            XUp = 0x100,
            Wheel = 0x800,
            VirtualDesk = 0x4000,
            Absolute = 0x8000
        }
    }
}

