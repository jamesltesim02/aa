﻿namespace alipayhook
{
    using System;

    public class Log
    {
        private static LogManager logManager;

        static Log()
        {
            InfaceMaxtoCode.Startup();
            old_acctor_mc();
        }

        private static void old_acctor_mc()
        {
            logManager = new LogManager();
        }

        public static void WriteLog(string Ol1)
        {
        }

        public static void WriteLog(LogFile O0O1l01, string O0O)
        {
        }

        public static void WriteLog(string OlOlOOl, string O1l)
        {
        }
    }
}

