﻿namespace alipayhook.Properties
{
    using System;
    using System.CodeDom.Compiler;
    using System.Configuration;
    using System.Runtime.CompilerServices;

    [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0"), CompilerGenerated]
    internal sealed class Settings : ApplicationSettingsBase
    {
        private static Settings defaultInstance;

        static Settings()
        {
            InfaceMaxtoCode.Startup();
            old_acctor_mc();
        }

        private static void old_acctor_mc()
        {
        }

        public static Settings Default
        {
            get
            {
            }
        }
    }
}

