﻿namespace Ysdm
{
    using System;
    using System.Collections.Generic;

    public class YsHttpUtil
    {
        static YsHttpUtil()
        {
            InfaceMaxtoCode.Startup();
        }

        public static string Post(string O00, Dictionary<object, object> OO10l)
        {
        }

        public static string Post(string Oll, IDictionary<object, object> O111O, byte[] O1l0l1l0)
        {
        }

        public static bool YsdmAnalyCode(ref byte[] OO1l, ref string O0010lll1)
        {
        }
    }
}

