﻿namespace ToolsLibrary
{
    using System;
    using System.Runtime.InteropServices;
    using System.Text;

    public class IniFile
    {
        public string path;

        static IniFile()
        {
            InfaceMaxtoCode.Startup();
        }

        public IniFile(string O011110)
        {
        }

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string O1O1O0l, string OO0, string O0O, StringBuilder Ol00lO, int OO1l, string OOO1Oll0);
        public string IniReadValue(string OOOOO01, string OO1)
        {
        }

        public void IniWriteValue(string OOl0011, string OlO, string OOO1l)
        {
        }

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string OO1O0l1, string O1O, string O01, string Ol111O1l);
    }
}

