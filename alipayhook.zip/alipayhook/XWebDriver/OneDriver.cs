﻿namespace XWebDriver
{
    using OpenQA.Selenium;
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class OneDriver
    {
        public IWebDriver wd;
        private Browsers O1110ll;

        static OneDriver()
        {
            InfaceMaxtoCode.Startup();
        }

        public OneDriver(Browsers OlOl100O11, object O1l0O1 = null)
        {
        }

        public void AlertAccept()
        {
        }

        public void AlertDismiss()
        {
        }

        public void Back()
        {
        }

        public void Cleanup()
        {
            this.wd.Quit();
        }

        public void ClickAndHoldOnElement(IWebElement OOO10O0)
        {
        }

        public void ClickElement(IWebElement Oll1lll)
        {
        }

        public void ContextClickOnElement(IWebElement O0OlO1O)
        {
        }

        public void DeleteAllCookies()
        {
        }

        public void DoubleClickElement(IWebElement O0OlOOl)
        {
        }

        public void DragAndDropElement(IWebElement OO1l0l, IWebElement OOOOO0)
        {
        }

        public void ElementScrollToBottom(IWebElement OO010l0)
        {
        }

        public void ExecuteJS(string O0)
        {
        }

        public void ExecuteScript(string O0)
        {
        }

        public IWebElement FindElement(By Ol, IWebElement O0l = null)
        {
        }

        public IWebElement FindElementById(string Ol, IWebElement OO0 = null)
        {
        }

        public IWebElement FindElementByLinkText(string O001, IWebElement O0O = null)
        {
        }

        public IWebElement FindElementByName(string Ol1l, IWebElement OO1 = null)
        {
        }

        public IWebElement FindElementByXPath(string OOO1l, IWebElement OO1 = null)
        {
        }

        public IList<IWebElement> FindElements(By Ol, IWebElement O10 = null)
        {
        }

        public IList<IWebElement> FindElementsByClassName(string O0101l1, IWebElement Oll = null)
        {
        }

        public IList<IWebElement> FindElementsByCssSelector(string OOO, IWebElement O0l = null)
        {
        }

        public IList<IWebElement> FindElementsByLinkText(string O111, IWebElement O01 = null)
        {
        }

        public IList<IWebElement> FindElementsByPartialLinkText(string O000, IWebElement OO1 = null)
        {
        }

        public IList<IWebElement> FindElementsByTagName(string O1O10O1, IWebElement OOO = null)
        {
        }

        public IList<IWebElement> FindElementsByXPathName(string OOOl0, IWebElement O11 = null)
        {
        }

        public void Forward()
        {
        }

        public string GetAlertString()
        {
        }

        public Dictionary<string, string> GetAllCookies()
        {
        }

        public string GetPageTitle()
        {
        }

        public Screenshot GetScreenshot()
        {
        }

        public string GetUrl()
        {
        }

        public void GoToDefault()
        {
        }

        public void GoToFrame(IWebElement O1O10)
        {
        }

        public void GoToFrame(string O0lO)
        {
        }

        public void GoToUrl(string O0l)
        {
        }

        public void GoToWindow(string OOlOO, bool O1l0llO1l1)
        {
        }

        public void ImplicitlyWait(int O1Ollll)
        {
        }

        private IWebDriver OO0100lO10lll(object O01O1lO)
        {
        }

        private bool OO110l(By OO100011)
        {
        }

        public void PageScrollToBottom()
        {
        }

        public void PageScrollToRight()
        {
        }

        public void Refresh()
        {
        }

        public void SendKeys(IWebElement O, string OOO, int O1ll0l = 300)
        {
        }

        public void SendKeysToElement(IWebElement OOlOlO0, string O0l0)
        {
        }

        public string TakeScreenshot(By O0 = null)
        {
        }

        public IWebElement WaitElement(By Oll1l1ll, int O1lOOl0)
        {
        }

        public IWebElement WaitForElement(string Ol)
        {
        }

        public void WaitForPage(string O101l)
        {
        }

        public void WaitLoadOver(int O010O01)
        {
        }

        [CompilerGenerated]
        private sealed class O1OOO11l11OO0O1Oll11
        {
            public string title;

            static O1OOO11l11OO0O1Oll11()
            {
                InfaceMaxtoCode.Startup();
            }

            internal bool <WaitForPage>b__0(IWebDriver O)
            {
            }
        }

        [CompilerGenerated]
        private sealed class OOOl11l111101OlO1O10
        {
            public By _locator;

            static OOOl11l111101OlO1O10()
            {
                InfaceMaxtoCode.Startup();
            }

            internal IWebElement <WaitElement>b__0(IWebDriver O) => 
                O.FindElement(this._locator);
        }

        [CompilerGenerated]
        private sealed class OOOll10Ol0OOOll00llO1
        {
            public string id;

            static OOOll10Ol0OOOll00llO1()
            {
                InfaceMaxtoCode.Startup();
            }

            internal IWebElement <WaitForElement>b__0(IWebDriver Ol)
            {
            }
        }
    }
}

