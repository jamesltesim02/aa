﻿namespace XWebDriver
{
    using System;

    public enum Browsers
    {
        Chrome,
        PhantomJS,
        Firefox,
        IE,
        Safari,
        Edge
    }
}

