﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

public class InfaceMaxtoCode
{
    private static bool started = false;
    private static IntPtr AppImageBase = IntPtr.Zero;
    private static int ImportRuntimeSize = 0;

    private static string ByteToString(byte[] O0l11) => 
        Encoding.ASCII.GetString(O0l11);

    private static string ByteToString(byte[] O010l, int O010O, int OO0O1) => 
        Encoding.ASCII.GetString(O010l, O010O, OO0O1);

    [DllImport("attick.dll", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Unicode, SetLastError=true, ExactSpelling=true)]
    private static extern int CheckRuntime(IntPtr OOO);
    [DllImport("attick64.dll", EntryPoint="CheckRuntime", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Unicode, SetLastError=true, ExactSpelling=true)]
    private static extern int CheckRuntime64(IntPtr OlO1OlllO);
    [DllImport("attick.dll", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern IntPtr EncryptString(IntPtr O1O, int Oll);
    [DllImport("attick64.dll", EntryPoint="EncryptString", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern IntPtr EncryptString64(IntPtr O0001OlO0, int OO11OlOO);
    [DllImport("attick.dll", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern IntPtr GetModuleBase(string O1O);
    [DllImport("attick64.dll", EntryPoint="GetModuleBase", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern IntPtr GetModuleBase64(string OlO0O0011Ol0);
    [DllImport("KERNEL32.DLL", EntryPoint="GetModuleHandleA", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern IntPtr GetModuleHandle(string OllOO001OllO);
    private static string GetRuntimeName()
    {
        byte[] buffer = new byte[10];
        buffer[0] = 0x61;
        buffer[1] = 0x74;
        buffer[2] = 0x74;
        buffer[3] = 0x69;
        buffer[4] = 0x63;
        buffer[5] = 0x6b;
        buffer[6] = 0x2e;
        buffer[7] = 100;
        buffer[8] = 0x6c;
        buffer[9] = 0x6c;
        return ByteToString(buffer);
    }

    public static string GetString(uint OO1l0101)
    {
        while (true)
        {
            string str = "";
            int num = 3;
            while (true)
            {
                switch (num)
                {
                    case 0:
                    case 2:
                        return str;

                    case 1:
                    {
                        str = Marshal.PtrToStringAnsi(EncryptString(AppImageBase, (int) OO1l0101));
                        if (1 != 0)
                        {
                        }
                        num = 0;
                        continue;
                    }
                    case 3:
                    {
                        if (IntPtr.Size == 4)
                        {
                            num = 1;
                            continue;
                        }
                        str = Marshal.PtrToStringAnsi(EncryptString64(AppImageBase, (int) OO1l0101));
                        num = 2;
                        continue;
                    }
                    default:
                        break;
                }
                break;
            }
        }
    }

    private static bool ImportRuntime(string O1111)
    {
        bool flag;
        int num3 = 0;
        while (true)
        {
            byte[] buffer;
            switch (num3)
            {
                case 1:
                    return true;

                case 2:
                    if (1 != 0)
                    {
                    }
                    try
                    {
                        while (true)
                        {
                            while (true)
                            {
                                string runtimeName = GetRuntimeName();
                                string location = Assembly.GetExecutingAssembly().Location;
                                num3 = 4;
                                while (true)
                                {
                                    string tempPath;
                                    string str4;
                                    switch (num3)
                                    {
                                        case 0:
                                        case 2:
                                        {
                                            str4 = tempPath;
                                            num3 = 5;
                                            continue;
                                        }
                                        case 1:
                                            try
                                            {
                                                byte[] buffer2 = new byte[ImportRuntimeSize + 1];
                                                FileStream stream = new FileStream(location, FileMode.Open, FileAccess.Read, FileShare.Read);
                                                stream.Seek((long) (((int) stream.Length) - ImportRuntimeSize), SeekOrigin.Begin);
                                                stream.Read(buffer2, 0, ImportRuntimeSize);
                                                stream.Close();
                                                FileStream stream2 = new FileStream(str4 + runtimeName, FileMode.Create, FileAccess.Write, FileShare.Write);
                                                stream2.Seek(0L, SeekOrigin.Begin);
                                                stream2.Write(buffer2, 0, ImportRuntimeSize);
                                                stream2.Close();
                                            }
                                            catch
                                            {
                                                tempPath = Path.GetTempPath();
                                                str4 = (tempPath.Substring(tempPath.Length - 1, 1) != ByteToString(buffer, 3, 1)) ? (tempPath + ByteToString(buffer, 3, 1)) : tempPath;
                                                string environmentVariable = Environment.GetEnvironmentVariable(ByteToString(buffer, 4, 4));
                                                if (environmentVariable.IndexOf(str4) == -1)
                                                {
                                                    SetEnvironmentVariable(ByteToString(buffer, 4, 4), environmentVariable + ByteToString(buffer, 1, 1) + str4.Replace(ByteToString(buffer, 0, 1), ByteToString(buffer, 3, 1)));
                                                }
                                                if (!File.Exists(str4 + runtimeName))
                                                {
                                                    byte[] buffer3 = new byte[ImportRuntimeSize + 1];
                                                    FileStream stream3 = new FileStream(location, FileMode.Open, FileAccess.Read, FileShare.Read);
                                                    stream3.Seek((long) (((int) stream3.Length) - ImportRuntimeSize), SeekOrigin.Begin);
                                                    stream3.Read(buffer3, 0, ImportRuntimeSize);
                                                    stream3.Close();
                                                    FileStream stream4 = new FileStream(str4 + runtimeName, FileMode.Create, FileAccess.Write, FileShare.Write);
                                                    stream4.Seek(0L, SeekOrigin.Begin);
                                                    stream4.Write(buffer3, 0, ImportRuntimeSize);
                                                    stream4.Close();
                                                }
                                            }
                                            break;

                                        case 3:
                                        {
                                            tempPath = O1111;
                                            num3 = 0;
                                            continue;
                                        }
                                        case 4:
                                        {
                                            if (O1111.Substring(O1111.Length - 1, 1) == ByteToString(buffer, 3, 1))
                                            {
                                                num3 = 3;
                                                continue;
                                            }
                                            tempPath = O1111 + ByteToString(buffer, 3, 1);
                                            num3 = 2;
                                            continue;
                                        }
                                        case 5:
                                        {
                                            if (File.Exists(str4 + runtimeName))
                                            {
                                                break;
                                            }
                                            num3 = 1;
                                            continue;
                                        }
                                        case 6:
                                            return flag;

                                        default:
                                        {
                                            continue;
                                        }
                                    }
                                    flag = true;
                                    num3 = 6;
                                }
                            }
                        }
                    }
                    catch
                    {
                        flag = false;
                    }
                    break;

                default:
                {
                    if (ImportRuntimeSize == 0)
                    {
                        num3 = 1;
                    }
                    else
                    {
                        buffer = new byte[] { 0x2f, 0x3a, 0x3b, 0x5c, 0x70, 0x61, 0x74, 0x68, 0 };
                        num3 = 2;
                    }
                    continue;
                }
            }
            break;
        }
        return flag;
    }

    private static void LicenseHelper()
    {
    }

    private static void LoadRuntimes()
    {
        IntPtr zero;
        int num3;
    TR_0035:
        while (true)
        {
            zero = IntPtr.Zero;
            num3 = 7;
            break;
        }
        goto TR_0033;
    TR_0007:
        num3 = 14;
    TR_0033:
        while (true)
        {
            b d;
            string location;
            string runtimeName;
            int num;
            string str3;
            IntPtr moduleHandle;
            int num2;
            switch (num3)
            {
                case 0:
                    throw new Exception("Not find manager image of memory, Program exception !");

                case 1:
                {
                    if (d == b.b)
                    {
                        num3 = 20;
                        continue;
                    }
                    num = CheckRuntime64(zero);
                    num3 = 8;
                    continue;
                }
                case 2:
                case 8:
                {
                    num3 = 11;
                    continue;
                }
                case 3:
                {
                    location = "alipayhook.exe";
                    num3 = 0x10;
                    continue;
                }
                case 4:
                {
                    str3 = "UNKWON ERROR";
                    num2 = num;
                    num3 = 0x23;
                    continue;
                }
                case 5:
                case 0x18:
                    goto TR_0007;

                case 6:
                {
                    started = true;
                    num3 = 15;
                    continue;
                }
                case 7:
                    if (!started)
                    {
                        num3 = 6;
                        continue;
                    }
                    return;

                case 9:
                case 10:
                case 0x16:
                case 0x1a:
                case 0x1f:
                case 0x21:
                    throw new Exception(str3);

                case 11:
                {
                    if (num != 0)
                    {
                        num3 = 4;
                        continue;
                    }
                    moduleHandle = GetModuleHandle(runtimeName);
                    num3 = 12;
                    continue;
                }
                case 12:
                {
                    num3 = (d != b.b) ? 0x1c : 0x13;
                    continue;
                }
                case 13:
                    started = MainDLL(moduleHandle, zero);
                    return;

                case 14:
                {
                    if (zero == IntPtr.Zero)
                    {
                        num3 = 0;
                        continue;
                    }
                    if (1 != 0)
                    {
                    }
                    AppImageBase = zero;
                    runtimeName = GetRuntimeName();
                    num = 5;
                    num3 = 1;
                    continue;
                }
                case 15:
                {
                    if (IntPtr.Size != 4)
                    {
                        num3 = 0x1b;
                        continue;
                    }
                    d = b.b;
                    num3 = 0x20;
                    continue;
                }
                case 0x10:
                    break;

                case 0x11:
                    if (zero == IntPtr.Zero)
                    {
                        num3 = 0x22;
                        continue;
                    }
                    goto TR_0007;

                case 0x12:
                {
                    if (d == b.b)
                    {
                        num3 = 0x17;
                        continue;
                    }
                    zero = GetModuleBase64("alipayhook.exe");
                    num3 = 5;
                    continue;
                }
                case 0x13:
                    started = MainDLL(moduleHandle, zero);
                    return;

                case 20:
                {
                    num = CheckRuntime(zero);
                    num3 = 2;
                    continue;
                }
                case 0x15:
                {
                    num3 = 0x16;
                    continue;
                }
                case 0x17:
                {
                    zero = GetModuleBase("alipayhook.exe");
                    num3 = 0x18;
                    continue;
                }
                case 0x19:
                case 0x20:
                {
                    location = Assembly.GetExecutingAssembly().Location;
                    num3 = 30;
                    continue;
                }
                case 0x1b:
                {
                    d = b.d;
                    num3 = 0x19;
                    continue;
                }
                case 0x1c:
                {
                    if (d == b.a)
                    {
                        num3 = 13;
                        continue;
                    }
                    started = MainDLL64(moduleHandle, zero);
                    num3 = 0x1d;
                    continue;
                }
                case 0x1d:
                    return;

                case 30:
                {
                    if (location != "")
                    {
                        break;
                    }
                    num3 = 3;
                    continue;
                }
                case 0x22:
                {
                    num3 = 0x12;
                    continue;
                }
                case 0x23:
                {
                    switch (num2)
                    {
                        case 1:
                        {
                            str3 = "Not find Framework Runtime, Please check you Framework!\n\r";
                            num3 = 0x21;
                            continue;
                        }
                        case 2:
                        {
                            str3 = "The Frmaework version is not support, please update your framework or restart setup .NET framework\n\rPlease get a new runtime support to website http://www.maxtocode.com/FrameworkSupport.html\n\r";
                            num3 = 9;
                            continue;
                        }
                        case 3:
                        {
                            str3 = "The Frmaework version is not support, please update your framework or restart setup .NET framework\n\rPlease get a new runtime support to website http://www.maxtocode.com/FrameworkSupport.html\n\rError Code : 0x0003\n\r";
                            num3 = 0x1f;
                            continue;
                        }
                        case 4:
                        {
                            str3 = "Maker Decoder Error\n\r";
                            num3 = 10;
                            continue;
                        }
                        case 5:
                        {
                            str3 = "Imports Runtime DLL is Error\n\r";
                            num3 = 0x1a;
                            continue;
                        }
                    }
                    num3 = 0x15;
                    continue;
                }
                default:
                    goto TR_0035;
            }
            zero = GetModuleHandle(location);
            num3 = 0x11;
        }
        goto TR_0035;
    }

    [DllImport("attick.dll", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern bool MainDLL(IntPtr O0O, IntPtr OO1);
    [DllImport("attick64.dll", EntryPoint="MainDLL", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern bool MainDLL64(IntPtr OlO0ll1l0O0, IntPtr OOl1O1l);
    [DllImport("KERNEL32.DLL", EntryPoint="SetEnvironmentVariableA", CharSet=CharSet.Ansi, SetLastError=true, ExactSpelling=true)]
    private static extern bool SetEnvironmentVariable(string O0l1lO, string Oll1011);
    public static void Startup()
    {
        if (!started)
        {
            if (1 != 0)
            {
            }
            try
            {
                ImportRuntime(AppDomain.CurrentDomain.BaseDirectory);
                LoadRuntimes();
            }
            finally
            {
                LicenseHelper();
            }
        }
    }

    internal interface a
    {
    }

    public enum b
    {
        a,
        b,
        c,
        d
    }
}

