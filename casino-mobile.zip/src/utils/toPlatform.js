const getUserinfo = () => {
  return JSON.parse(localStorage.getItem('nb-casino-userinfo') || 'null') || null
}

export default () => {
  const userinfo = getUserinfo()
  let purl = decodeURIComponent(window.NBConfig.PLATFORM_URL)

  if (!window.NBConfig.FRONT_ID) {
    return
  }

  purl += `?frontId=${window.NBConfig.FRONT_ID}`
  if (userinfo) {
    const token = userinfo.token
    purl += `&token=${token}&loginName=${userinfo.memberAccount}`
  }

  window.location = purl
}
