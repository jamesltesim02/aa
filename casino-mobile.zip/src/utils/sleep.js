export default duration => new Promise(resolve => setTimeout(resolve, duration))
