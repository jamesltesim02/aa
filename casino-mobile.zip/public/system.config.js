;(function (w) {
  const params = new Map(location.href.split('?').pop().split('&').map(kv => kv.split('=')))

  let platformUrl = decodeURIComponent(params.get('nborigin') || '');

  w.NBConfig = {
    FRONT_ID: '100771011B79v4yw',
    API_URL: 'http://casino.nbbets.com/',
    PLATFORM_URL: platformUrl || 'http://nb2.nbbets.com/',
  };
})(window);
