import React, { Component } from 'react';
import { BrowserRouter, Switch, Route, Redirect } from 'react-router-dom';

import SignIn from '@/components/Sign/SignIn';
import MemberCenter from '@/components/MemberCenter';


class AppRouter extends Component {
  render() {
    return (
      <BrowserRouter>
        <Switch>
          <Route exact path="/member" component={ MemberCenter } />
          <Route path="/sign/in" component={ SignIn } />
          <Redirect to="/member" />
        </Switch>
      </BrowserRouter>
    );
  }
}
export default AppRouter;
