import { loadFromStorage, saveToStorage } from '@/utils/StorageUtil';

const actionTypes = {
  REFRESH: 'REFRESH',
  SET_NBINFO: 'SET_NBINFO',
  DEFAULT: 'DEFAULT',
};

const defaultState = {
  nbinfo: null,
  isNbjc: false,
};

const reducers = {
  [actionTypes.SET_NBINFO](state, { nbinfo }) {
    const newState = {
      nbinfo,
      isNbjc: !!nbinfo,
    };
    saveToStorage('ag-portal-nbjcinfo', newState)
    return newState;
  },
  [actionTypes.REFRESH](state) {
    const  newState = loadFromStorage('ag-portal-nbjcinfo', defaultState);
    return newState;
  },
  [actionTypes.DEFAULT]: state => state,
};

export default (state = defaultState, action) => {
  return (reducers[action.type] || reducers[actionTypes.DEFAULT]) (state, action)
}

export const nbjcActions = {
  refresh() {
    return { type: actionTypes.REFRESH };
  },
  setNbinfo(nbinfo) {
    return {
      type: actionTypes.SET_NBINFO,
      nbinfo,
    };
  },
};
