import { loadFromStorage, saveToStorage } from '@/utils/StorageUtil';

const actionTypes = {
  REFRESH: 'REFRESH',
  SET_MEMBERINFO: 'SET_MEMBERINFO',
  DEFAULT: 'DEFAULT',
};

const defaultState = {
  memberInfo: null,
  isLoged: false,
};

const reducers = {
  [actionTypes.SET_MEMBERINFO](state, { memberInfo }) {
    const newState = {
      memberInfo,
      isLoged: !!memberInfo,
    };
    saveToStorage('ag-portal-userinfo', newState)
    return newState;
  },
  [actionTypes.REFRESH](state) {
    const  newState = loadFromStorage('ag-portal-userinfo', defaultState);
    return newState;
  },
  [actionTypes.DEFAULT]: state => state,
};

export default (state = defaultState, action) => {
  return (reducers[action.type] || reducers[actionTypes.DEFAULT]) (state, action)
}

export const appActions = {
  refresh() {
    return { type: actionTypes.REFRESH };
  },
  setMemberinfo(memberInfo) {
    return {
      type: actionTypes.SET_MEMBERINFO,
      memberInfo,
    };
  },
};
