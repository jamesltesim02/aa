import { combineReducers ,createStore} from 'redux';
import app from './modules/app';
import nbjc from './modules/nbjc';

export default createStore(combineReducers({
  app,
  nbjc,
}));
