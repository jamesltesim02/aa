import React from 'react';
import {connect} from 'react-redux';
import {
  Form, Icon, Input, Button,
  //Checkbox,
} from 'antd';
import { appActions } from '@/store/modules/app';
import { agLogin, transferToGame } from '@/api/portalAgyy';
import getParameter from '@/utils/getParameter';

import './SignIn.css';

class SignIn extends React.Component {

  constructor(props) {
    super(props);

    this.state = {};
  }

  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields(async (err, values) => {
      if (err) {
        console.log('Received values of form: ', values);
        return;
      }

      // 登录
      const result = await agLogin({
        ...values,
        verification: '',
      });

      // 余额转至游戏中
      const transferResult = await transferToGame();

      this.props.setMemberinfo({
        ...result,
        token: transferResult.token,
      });
      const nborigin = getParameter('nborigin');
      if (nborigin) {
        window.location = `${decodeURIComponent(nborigin)}?token=${transferResult.token}`;
        return;
      }
      this.props.history.push('/member');
    });
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    const {
      nbjc: {
        isNbjc,
        nbinfo,
      },
    } = this.props; 
    return (
      <div className="sign-in">
        <Form onSubmit={this.handleSubmit} className="login-form">
          <Form.Item>
            {getFieldDecorator('loginName', {
              rules: [
                {
                  required: true,
                  message: '请输入账号!'
                },
                {
                  pattern: /(^[a|A][s|S|g|G][a-zA-Z0-9]{4,20}$)|(^1[3458]\d{9}|17[2-9]\d{8}|19[89]\d{8}|166\d{8}$)/,
                  message: '请输入正确手机号码或游戏账号！',
                },
              ],
            })(
              <Input prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />} placeholder="账号" />
            )}
          </Form.Item>
          <Form.Item>
            {getFieldDecorator('password', {
              rules: [
                {
                  required: true,
                  message: '请输入密码!',
                },
                {
                  min: 8,
                  max: 10,
                  message: '请输入8~10位的密码！',
                },
                {
                  pattern: /^[a-zA-Z0-9]{6,10}$/,
                  message: '密码格式错误!',
                }
              ],
            })(
              <Input prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />} type="password" placeholder="密码" />
            )}
          </Form.Item>
          <Form.Item>
            {/* {getFieldDecorator('remember', {
              valuePropName: 'checked',
              initialValue: true,
            })(
              <Checkbox>记住我</Checkbox>
            )} */}
            <a className="login-form-forgot" href="/">忘记密码</a>
            <Button type="primary" htmlType="submit" className="login-form-button">登录</Button>
            <a href="/">没有账号?立即注册!</a>
          </Form.Item>
          {
            isNbjc && <Form.Item>
              <a href={nbinfo.origin}>暂不登录,返回游戏主页</a>
            </Form.Item>
          }
          
        </Form>
      </div>
    );
  }
}

export default connect(
  state => state,
  appActions,
) (
  Form.create({ name: 'normal_login' })(SignIn)
);
