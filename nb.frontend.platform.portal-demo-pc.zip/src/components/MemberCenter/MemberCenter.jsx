import React from 'react'
import { connect } from 'react-redux';
// import { agLogout } from '@/api/portalAgyy';
import { appActions } from '@/store/modules/app';
import './MemberCenter.css';

class MemberCenter extends React.Component {
  constructor(props) {
    super(props);
    if (!props.app.isLoged) {
      this.props.history.push('/sign/in');
    }
  }
  async handleLogout() {
    // await agLogout();
    this.props.setMemberinfo(null);
    this.props.history.push('/sign/in');
  }
  render() {
    if (!this.props.app.isLoged) {
      return null;
    }
    const {
      app: {
        isLoged,
        memberInfo: {
          loginName,
          token,
        },
      },
      nbjc: {
        isNbjc,
        nbinfo: {
          origin,
        },
      },
    } = this.props;
    let nburl = '';
    if (isNbjc) {
      nburl = `${origin}?token=${token}`
    }
    return (
      <div>
        <div>member center</div>
        { isLoged && (<h2>Welcome: { loginName }</h2>) }
        { 
          // isLoged && (
          //   <div>
          //     <button
          //       className="btn-log-out"
          //       onClick={this.handleLogout}
          //     >退出登陆</button>
          //   </div>
          // )
        }
        { isNbjc && <a href={nburl}>返回游戏主页</a> }
      </div>
    );
  }
}

export default connect(
  state => state,
  appActions,
)(MemberCenter);