import React from 'react';
import { connect } from 'react-redux';
import { nbjcActions } from '@/store/modules/nbjc';
import { appActions } from '@/store/modules/app';
import getParameter from '@/utils/getParameter';

class Init extends React.Component {
  componentWillMount() {
    this.props.appRefresh();
    this.props.nbjcRefresh();
    const nborigin = getParameter('nborigin');
    if (nborigin) {
      this.props.setNbinfo({
        origin: decodeURIComponent(nborigin),
      });
    }
  }
  render() {
    return null;
  }
}

export default connect(
  state => state,
  {
    appRefresh: appActions.refresh,
    nbjcRefresh: nbjcActions.refresh,
    setNbinfo: nbjcActions.setNbinfo,
  },
)(Init);