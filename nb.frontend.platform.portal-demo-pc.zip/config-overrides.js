/* config-overrides.js */
const path = require('path');

module.exports = function override(config, env) {
  //do stuff with the webpack config...
  config.resolve = {
    ...config.resolve,
    alias: {
      '@': path.resolve('src')
    }
  };

  const rule = config.module.rules.find(r => r.oneOf);

  if (rule && rule.oneOf.length) {
    const oneOf = rule.oneOf.find(o => String(o.test).includes('js'));
    if (oneOf) {
      oneOf.options.babelrc = true;
    }
  }


  return config;
}