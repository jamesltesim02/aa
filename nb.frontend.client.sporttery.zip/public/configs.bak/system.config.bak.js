;(function () {
  var protocol = location.protocol,
  host = location.host,
  hostname = location.hostname,
  pathname = location.pathname,
  search = location.search,
  hash = location.hash,
  domain = hostname;
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(domain)) {
    var ds = domain.split('.');
    domain = Array.prototype.join.call([ds.pop(), ds.pop()].reverse(), '.');
  }

  window.NBConfig = {
    // 商户编号
    // PORTAL_CODE: 'B06',
    /**
     * 应用模式
     * 1: 包网
     * 2: Seamless模式
     * 3: 轻量包网模式(亚游接入模式, 会员相关接口用商户)
     *
     * 业务代码中进行比较判断时需要使用constants.js中的AppModels常量来判断
     * 不建议在代码中硬编码
     */
    APP_MODE: 2,
    /**
     * FONT_ID对照
     * 亚游: 102001011JIaThBA (B79)
     * 凯时: 1000610117Qe1Gj0 (A06)
     * 酷游: 102061011cYgTGB2 (B06 凯发电游)
     * 永乐: 101031011k3Lx9Tf (E03)
     * 和记: 1010410116Ea5Hq7 (E04)
     * 风暴竞技: 100661011cYsdfsB2
     * 
     * 劲彩现金网: 100771011B79v4yw
     */
    FRONT_ID: '100771011B79v4yw',
    // 首页是否是列表页 （B06需要配置成true）
    HOME_IS_MATCH_LIST: false,
    // 默认皮肤 white 白色, black 黑色
    THEME: 'white',
    // 是否显示滚球，用于设置所有项目默认是否开滚球
    SHOW_LIVE: true,
    // 首页样式, 1: 经典，2：亚游样式，3：永乐样式
    // HOME_STYLE: 3,
    HOME_STYLE: 2,
    /**
     * 赛程列表展示样式
     * 1: 宽松两胜平负盘口样式
     * 2: 紧凑两胜平负盘口样式
     * 3: 紧凑单盘口样式
     * 4: 宽松让分大和小盘口样式
     */
    MATCH_LIST_STYLE: 1,
    /**
     * 投注模式
     * 1: 小白模式
     * 2: 专家模式
     */
    BETTING_MODE: 3,
    // 是否允许同场比赛选择多个投注项
    ALLOW_SAME_MATCH: true,
    // 是否允许单式投注时同时投注多个投注项
    ALLOW_MULT_OPTION: true,
    // 串关时最多可选的投注项
    MAX_BETTING_COUNT: 10,
    // 串关注单是否拆分
    FOLDS_NEED_SPLIT: false,
    // 现金网接口
    CASINO_API_URL: 'http://casino.nbbets.com/',
    // 比赛数据查询接口
    PULL_URL: 'https://nbpull.nbbets.com/',
    // PULL_URL: 'https://pull.agvipp8.com/',
    // 点水接口
    QUOTE_URL: 'https://nbsalesrisk.nbbets.com/',
    // 投注接口
    BET_URL: 'https://nbbet.nbbets.com/api/bet/',
    // 提前结算查询接口
    CASH_URL: 'https://nbsettlement.nbbets.com/',
    // 推送接口
    PUSH_URL: 'wss://nbpush.nbbets.com/ws',
    // 后台配置的静态文件cdn地址
    RESOURCE_URL: 'https://nbimges.nbbets.com/cdn/',
    // 前端静态资源CDN地址
    // STATIC_URL: 'http://cor.nbbets.com',
    STATIC_URL: protocol + '//' + host + '/',
    // 图文直播等动画地址
    LIVE_MEDIA_URL: 'http://media.nbbets.com/',
    // LIVE_MEDIA_URL: 'http://cor.nbbets.com/',
    // LIVE_MEDIA_URL: 'http://sir.nbbets.com/',
    // 商户api地址
    // PORTAL_API_URL: 'http://uatm.ag288.com/',
    PORTAL_API_URL: protocol + '//' + host + '/',
    // 商户api请求头设置
    PORTAL_API_HEADS: {
      // 'Content-Type': 'application/json;charse=UTF-8',
      'x-requested-with': 'XMLHttpRequest',
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    },
    
    /**
     * 开放的体育类型列表
     * 
     *   10 = Soccer 足球
     *   11 = Basketball 篮球
     *   12 = Tennis 网球 (暂不支持)
     *   14 = LOL 英雄联盟
     *   15 = Dota2 刀塔2 (暂不支持)
     *   16 = ArenaOfValor 王者荣耀 (暂不支持)
     *   17 = CounterStrike 反恐精英
     *   18 = StarCraft 星际争霸 (暂不支持)
     *   19 = Overwatch 守望先锋 (暂不支持)
     *   888 = Blockade 闯关 (开发中)
     *   999 = Jackpot 奖池 (开发中)
     */
    AVAILABLE_SPORTS: [ // SHOW_LIVE 用于控制单项是否开滚球，不填则用所有球类的默认设置
      // 10,
      { SPORT_ID: 10, SHOW_LIVE: true },
      { SPORT_ID: 11, SHOW_LIVE: true },
      888,
      // 999,
      14,
      17,
      // { SPORT_ID: 10, SHOW_LIVE: true },
      // { SPORT_ID: 11 },
      // { SPORT_ID: 14 },
      // { SPORT_ID: 17 },
      // 下面4个暂时无比赛，先隐藏
      // 15,
      // 16,
      // 18,
      // 19,
    ],
    // 以下都为商户自定义项，不配用默认的
    PORTAL_SETTING: {
      // 个人中心跳转地址
      // USER_CENTER_URL: 'http://m3.ksbet168.net/#/minecenter',
      // 登录页面地址
      // LOGIN_PAGE_URL: 'http://m3.ksbet168.net/#/login',
      // 存款地址
      // DEPOSIT_PAGE_URL: 'http://baidu.com',
      // 优惠信息页面地址
      // PROMOTION_PAGE_URL: '',
      // 刷新token页面地址
      // TOKEN_REFRESH_URL: 'http://m3.ksbet168.net/#/nbtest',

      // B06 配置 start ===========================================================
      // USER_CENTER_URL: protocol+'//member2.' + domain + '/userCenter',
      // LOGIN_PAGE_URL: protocol+'//member2.' + domain + '/registerLogin/1',
      // DEPOSIT_PAGE_URL: protocol+'//member2.' + domain + '/deposit',
      // PROMOTION_PAGE_URL: protocol+'//member2.' + domain + '/promotions',
      // TOKEN_REFRESH_URL: protocol+'//member2.' + domain + '/tokenPage',
      // FAVICON_URL: protocol + '//' + host + '/img/favicons/b06.ico',
      // // 电竞站地址
      // SITE_LINK_GAMING: 'https://m.k0803.com',
      // // 真人站地址
      // SITE_LINK_CASINO: 'http://m.k0886.com',
      // B06 配置 end==============================================================

      // E03 配置 start==============================================================
      // LOGIN_API: null, //{ URI: 'api/login', METHOD: 'post', PARAMS: { account: '', password: '' } },
      // TRANS_API: 'http://999.f66-online.com/doBusiness.do', //{ URI: 'api/transfer/local-game', METHOD: 'post' }, // 转额接口
      // USER_CENTER_URL: 'http://m.hvip11.com/register.htm', // 个人中心跳转地址
      // LOGIN_PAGE_URL: 'http://m.hvip11.com/login.htm', // 登录页面
      // TOKEN_REFRESH_URL: '', // 刷新token页面地址
      // SERVICE_CENTER_URL: 'https://www.f66-kefu.com/chat/chatClient/chatbox.jsp?companyID=8996&configID=3&info=userId', // 客服中心跳转地址
      // LOGIN_LOGO_URL: null,  // 注册登录页Logo地址
      // HOME_LOGO_URL: 'http://m.hvip11.com/static/E03M/_default/__static/__images/common/logo.png',//location.protocol + '//' + location.host + '/img/portal-logos/e03.png', // 首页页Logo地址
      // CLICK_SET_FULL_SCREEN: false, // 点击开启全屏模式，用于浏览器
      // DEPOSIT_PAGE_URL: 'http://m.hvip11.com/mem_deposit_new.htm',  //存款页面
      // FAVICON_URL: location.protocol + '//' + location.host + '/img/favicons/e03.ico', //favicon配置项
      // BACKGROUND_FILTER: true,
      // CLICK_SET_FULL_SCREEN: false,
      // E03 配置 end==============================================================

      // NB casino 配置 start============================================================
      LOGIN_API: null, //{ URI: 'api/login', METHOD: 'post', PARAMS: { account: '', password: '' } },
      TRANS_API: 'http://999.f66-online.com/doBusiness.do', //{ URI: 'api/transfer/local-game', METHOD: 'post' }, // 转额接口
      USER_CENTER_URL: 'http://user.nbbets.com/#/member', // 个人中心跳转地址
      LOGIN_PAGE_URL: 'http://user.nbbets.com/#/login', // 登录页面
      TOKEN_REFRESH_URL: '', // 刷新token页面地址
      SERVICE_CENTER_URL: 'https://www.f66-kefu.com/chat/chatClient/chatbox.jsp?companyID=8996&configID=3&info=userId', // 客服中心跳转地址
      LOGIN_LOGO_URL: null,  // 注册登录页Logo地址
      HOME_LOGO_URL: 'http://m.hvip11.com/static/E03M/_default/__static/__images/common/logo.png',//location.protocol + '//' + location.host + '/img/portal-logos/e03.png', // 首页页Logo地址
      CLICK_SET_FULL_SCREEN: false, // 点击开启全屏模式，用于浏览器
      DEPOSIT_PAGE_URL: 'http://m.hvip11.com/mem_deposit_new.htm',  //存款页面
      FAVICON_URL: location.protocol + '//' + location.host + '/img/favicons/e03.ico', //favicon配置项
      BACKGROUND_FILTER: true,
      CLICK_SET_FULL_SCREEN: false,
      // NB casino 配置 end==============================================================

      // A06 配置 start ===========================================================
      // // 弹窗页面是否模糊处理
      // BACKGROUND_FILTER: true,
      // // 登录api
      // LOGIN_API: null, //{ URI: 'api/login', METHOD: 'post', PARAMS: { account: '', password: '' } },
      // // 转额接口
      // TRANS_API: null, //{ URI: 'api/transfer/local-game', METHOD: 'post' },
      // // 个人中心跳转地址
      // USER_CENTER_URL: 'http://m3.ksbet168.net/#/minecenter',
      // // 登录页面
      // LOGIN_PAGE_URL: 'http://m3.ksbet168.net/#/login',
      // //注册页面
      // REGISTER_PAGE_URL: 'http://m3.ksbet168.net/#/register',
      // // 刷新token页面地址
      // TOKEN_REFRESH_URL: 'http://m3.ksbet168.net/#/nbtest',
      // // 客服中心跳转地址
      // SERVICE_CENTER_URL: 'https://www.ks015.com/chat/chatClient/chatbox.jsp?companyID=8991&configID=77&enterurl=www.134kb.com',
      // // 注册登录页Logo地址
      // LOGIN_LOGO_URL: '',
      // // 首页页Logo地址
      // HOME_LOGO_URL: location.protocol + '//' + location.host + '/img/portal-logos/a06.png',
      // // 点击开启全屏模式，用于浏览器
      // CLICK_SET_FULL_SCREEN: false,
      // // 存款页面
      // DEPOSIT_PAGE_URL: 'http://m3.ksbet168.net/#/deposit/from/2', 
      // // favicon配置项
      // FAVICON_URL: location.protocol + '//' + location.host + '/img/favicons/a06.ico',
      // A06 配置 end =============================================================

      SOCCER_1618_AVAILABLE: false,
      // favicon图标地址
      // FAVICON_URL: protocol + '//' + host + '/img/favicons/a06.ico',
      // SERVICE_CENTER_URL: 'https://www.baidu.com', // 客服中心跳转地址
      // LOGIN_API: { URI: 'api/login', METHOD: 'post', PARAMS: { account: '', password: '' } }, // 登录接口， account和password指定账户和密码对应的参数名
      // TRANS_API: { URI: 'api/transfer/local-game', METHOD: 'post' }, // 转额接口
      BACKGROUND_STYLE_ID: 0, // 黑色版风格，目前两种，0：浅黑色，1：深黑色
      // WELCOME_BACKGROUND_COLOR: 'blue', // 欢迎注册登录页背景默认颜色
      WELCOME_BACKGROUND_URL: 'http://img2.imgtn.bdimg.com/it/u=1958288144,3609050656&fm=26&gp=0.jpg', // 欢迎页背景图片地址
      WELCOME_H_BACKGROUND_URL: 'http://img3.imgtn.bdimg.com/it/u=3902215763,213670618&fm=26&gp=0.jpg', // 欢迎页横版背景图片地址
      WELCOME_LOGO_URL: '', // 欢迎页Logo地址
      LOGIN_LOGO_URL: '',  // 注册登录页Logo地址
      // HOME_LOGO_URL: protocol + '//' + host + '/img/portal-logos/a06.png', // 首页页Logo地址
      // 个人中心自定义跳转地址，为数组
      USER_CENTER_JUMP: [
        // { title: '体育直播', url: 'http://www.baidu.com' }
      ],
      BACKGROUND_FILTER: false, // 弹窗背景模糊处理
      SHOW_CHANGE_BET_MODE: true, // 是否显示切换投注模式
      CLICK_SET_FULL_SCREEN: false, // 点击开启全屏模式，用于浏览器
      WHITE_OPTION_COLOR: '', // 白色版比分和赔率颜色值
      BLACK_OPTION_COLOR: '', // 黑色版比分和赔率颜色值
      WHITE_HOME_ICON_COLOR: '', // 白色版首页图标颜色值
      BLACK_HOME_ICON_COLOR: '', // 黑色版首页图标颜色值
      WHITE_FAST_DATE_BACKGROUND: '', // 白色版首页快速投注日期背景颜色值
      BLACK_FAST_DATE_BACKGROUND: '', // 黑色版首页快速投注日期背景颜色值
      WHITE_TAB_COLOR: '', // 白色版底部Tab选中颜色值
      BLACK_TAB_COLOR: '', // 黑色版底部Tab选中颜色值
      WHITE_MATCH_TEXT_COLOR: '', // 白色版顶部赛程列表选中文字颜色值
      BLACK_MATCH_TEXT_COLOR: '', // 黑色版顶部赛程列表选中文字颜色值
      WHITE_MATCH_LINE_COLOR: '', // 白色版顶部赛程列表选中线条颜色值
      BLACK_MATCH_LINE_COLOR: '', // 黑色版顶部赛程列表选中线条颜色值
      WHITE_BOTTON_BACKGROUND: '', // 白色版按钮背景颜色值，不支持rgba
      BLACK_BOTTON_BACKGROUND: '', // 黑色版按钮背景颜色值，不支持rgba
      WHITE_LIVE_FLAG_COLOR: '', // 白色版滚球标志颜色值
      BLACK_LIVE_FLAG_COLOR: '', // 黑色版滚球标志颜色值
      WHITE_BET_ALERT_COLOR: '', // 白色版投注提示颜色值
      BLACK_BET_ALERT_COLOR: '', // 黑色版投注提示颜色值
      WHITE_BET_HIS_WIN_COLOR: '', // 白色版投注赢颜色值
      BLACK_BET_HIS_WIN_COLOR: '', // 黑色版投注赢颜色值
      WHITE_BET_HIS_LOSE_COLOR: '', // 白色版投注输颜色值
      BLACK_BET_HIS_LOSE_COLOR: '', // 黑色版投注输颜色值
      WHITE_ODDS_UPPER_COLOR: '', // 白色版赔率升高颜色值
      BLACK_ODDS_UPPER_COLOR: '', // 黑色版赔率升高颜色值
      WHITE_ODDS_LOWER_COLOR: '', // 白色版赔率降低颜色值
      BLACK_ODDS_LOWER_COLOR: '', // 黑色版赔率降低颜色值
    },
  };
})();

