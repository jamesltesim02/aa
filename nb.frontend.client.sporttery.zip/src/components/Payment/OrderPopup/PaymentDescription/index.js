import PaymentDescription from './PaymentDescription';

export default PaymentDescription;
