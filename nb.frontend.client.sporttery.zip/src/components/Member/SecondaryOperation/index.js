import SecondaryOperation from './SecondaryOperation';

export default SecondaryOperation;
