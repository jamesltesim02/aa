<template>
<svg width=".24rem" height=".19rem" style="width:.24rem;height:.19rem" viewBox="0 0 24 19">
  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g transform="translate(-334, -302)" :fill="color" fill-rule="nonzero">
      <g id="icon-shouwang" transform="translate(334, 301)">
        <path d="M2.05821667,15.7827841 L4.21312407,18.2561742 L9.4625419,13.1034103 L9.4625419,6.50559086 L7.68791227,10.3574878 L2.05821667,15.7827841 Z M4.14657546,19.9848536 L0.419853241,15.7114821 L6.77999907,9.58108738 L10.65091,0.948781829 L10.65091,13.6009404 L4.14657546,19.9848536 Z" id="Fill-4"></path>
        <path d="M14.2489715,13.1027765 L19.4983894,18.2555404 L21.6532968,15.7821503 L15.8936729,10.1730531 L14.2489715,6.50495706 L14.2489715,13.1027765 Z M19.564938,19.9889733 L13.0606035,13.6003066 L13.0606035,0.949732523 L16.9299299,9.58203808 L23.2900757,15.7108483 L19.564938,19.9889733 Z" id="Fill-6"></path>
      </g>
    </g>
  </g>
</svg>
</template>
<script>
export default {
  props: ['color'],
};
</script>
