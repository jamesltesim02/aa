<template>
<svg width=".27rem" height=".24rem" style="width:.27rem;height:.24rem" viewBox="0 0 27 24">
  <defs>
    <filter x="-2.1%" y="-12.5%" width="104.3%" height="125.0%" filterUnits="objectBoundingBox" id="filter-1">
      <feOffset dx="0" dy="1" in="SourceAlpha" result="shadowOffsetOuter1"></feOffset>
      <feGaussianBlur stdDeviation="1.5" in="shadowOffsetOuter1" result="shadowBlurOuter1"></feGaussianBlur>
      <feColorMatrix values="0 0 0 0 0.659332483   0 0 0 0 0.659332483   0 0 0 0 0.659332483  0 0 0 0.5 0" type="matrix" in="shadowBlurOuter1" result="shadowMatrixOuter1"></feColorMatrix>
      <feMerge>
        <feMergeNode in="shadowMatrixOuter1"></feMergeNode>
        <feMergeNode in="SourceGraphic"></feMergeNode>
      </feMerge>
    </filter>
  </defs>
  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g transform="translate(-9.000000, -30.000000)" fill="#FFFFFF" fill-rule="nonzero">
      <g filter="url(#filter-1)">
        <g transform="translate(12.000000, 32.000000)">
          <path d="M1.14269104,2.85050839 C0.512614379,2.85050839 0,2.2111293 0,1.42526782 C0,0.639379111 0.512614357,0 1.14269104,0 L19.857309,0 C20.4874075,0 21,0.639379085 21,1.42526782 C21,2.2111293 20.4874075,2.85050839 19.857309,2.85050839 L1.14269104,2.85050839 Z M1.14269104,10.458667 C0.512614379,10.458667 0,9.81926066 0,9.03329022 C0,8.24740151 0.512614357,7.6080224 1.14269104,7.6080224 L19.857309,7.6080224 C20.4874075,7.6080224 21,8.24740148 21,9.03329022 C21,9.81926066 20.4874075,10.458667 19.857309,10.458667 L1.14269104,10.458667 Z M0.916985867,17.8505356 C0.411362412,17.8505356 0,17.2111838 0,16.4252678 C0,15.6393519 0.411362394,15 0.916985867,15 L10.8710786,15 C11.3767196,15 11.7880645,15.6393519 11.7880645,16.4252678 C11.7880645,17.2111838 11.3767196,17.8505356 10.8710786,17.8505356 M15.3724604,17.8505356 C15.1670868,17.8505356 15,17.2111838 15,16.4252678 C15,15.6393519 15.1670868,15 15.3724604,15 L19.4156041,15 C19.6209849,15 19.7880645,15.6393519 19.7880645,16.4252678 C19.7880645,17.2111838 19.6209849,17.8505356 19.4156041,17.8505356" />
        </g>
      </g>
    </g>
  </g>
</svg>
</template>
