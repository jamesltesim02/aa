<template>
  <div
    v-if="false"
    class="token-refresher"
  ></div>
</template>
<style lang="less">
.token-refresher {
  display: none;
}
</style>
