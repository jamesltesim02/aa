import IconHome from './IconHome';

export default IconHome;
