<template>
  <div class="loading-bar"><icon-loading /></div>
</template>
<script>
import IconLoading from '@/components/common/icons/IconLoading';

export default {
  components: {
    IconLoading,
  },
};
</script>
