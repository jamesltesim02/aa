<template>
  <header class="nav-bar" :class="{ transparent: transparent }" >
    <div class="nav-content" :style="contentStyle">{{title}}<slot name="content" /></div>
    <div class="nav-operators">
      <v-touch v-if="backable" tag="a" @tap="goback" class="opr-back flex-center" >
        <icon-arrow />
      </v-touch>
      <v-touch class="opr-others flex-end" @tap="operateFun"><slot /></v-touch>
    </div>
  </header>
</template>
<script>
import { mapState, mapMutations } from 'vuex';
import { StorageKey } from '@/config/constants';
import { loadFromStorage, removeFromStorage } from '@/utils/StorageUtil';
import appConfig from '@/config/business.config';
import IconArrow from './icons/IconArrow';

export default {
  props: {
    title: String,
    backable: { type: Boolean, default: true },
    backurl: String,
    custBack: { type: Boolean, default: false },
    transparent: { type: Boolean, default: false },
    opacity: Number,
  },
  computed: {
    ...mapState('app', ['lastLocation', 'lastGoBackTime']),
    contentStyle() {
      return this.opacity !== undefined ? { opacity: this.opacity } : { };
    },
  },
  methods: {
    ...mapMutations('app', ['updateLastGoBackTime']),
    operateFun() {
      this.$emit('operate');
    },
    goback() {
      const fromURL = loadFromStorage(StorageKey.FROM_URL_KEY, null);
      if (fromURL) {
        window.location = decodeURIComponent(fromURL);
        removeFromStorage(StorageKey.FROM_URL_KEY);
        return;
      }
      if (Date.now() - this.lastGoBackTime < 1000) return;
      this.updateLastGoBackTime();
      if (this.backurl) {
        this.$router.replace(this.backurl);
        return;
      }
      if (this.custBack) {
        this.$emit('back');
        return;
      }
      if (!this.lastLocation) {
        this.$router.replace('/');
        return;
      }
      if (this.$route.path === '/login' && /^(4\d{2}|800|8[1-9]\d)$/.test(this.lastLocation.meta.index)) {
        this.$router.replace('/');
        return;
      }
      const isIframe = appConfig.iframePages.findIndex(p => p.test(this.$route.path)) > -1;
      if (isIframe) {
        this.$router.replace(this.lastLocation.path);
        return;
      }
      if (window.history.length < 2) {
        this.$router.replace('/');
        return;
      }
      this.$router.go(-1);
    },
  },
  components: { IconArrow },
};
</script>

<style lang="less">
.nav-bar {
  position: relative;
  width: 3.75rem;
  height: .44rem;
  background: #fff;
  color: #2e2f34;
  transition: all .5s;
  .nav-content {
    text-align: center;
    line-height: .44rem;
    font-size: .17rem;
  }
  .nav-operators {
    display: flex;
    position: absolute;
    top: 0;
    left: 0;
    height: .44rem;
    width: 100%;
    font-size: .15rem;
    z-index: 3;
    a { color: #fff; }
    .opr-others { flex-grow: 1; min-width: .44rem; height: .44rem; }
  }
  .opr-back { width: .54rem; height: .44rem; padding-right: .1rem; }
  .icon-arrow path { fill: #909090; }
}
.black .nav-bar {
  background: #28272d;
  color: #fff;
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(10px);
  box-shadow: 0 1px 0 0 rgba(0, 0, 0, 0.25);
  .icon-arrow path { fill: #bababa; }
}
.blue .nav-bar {
  background: #2e2f34;
  color: #ecebeb;
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(10px);
  box-shadow: 0 1px 0 0 rgba(0, 0, 0, 0.25);
  .icon-arrow path { fill: #bababa; }
}
.nav-bar.transparent {
  background: transparent;
  color: #fff;
  box-shadow: none;
  svg path { fill: #fff; }
}
.black .nav-bar.transparent {
  color: #fff;
  svg path { fill: #fff; }
}
.blue .nav-bar.transparent {
  color: #fff;
  svg path { fill: #fff; }
}
</style>
