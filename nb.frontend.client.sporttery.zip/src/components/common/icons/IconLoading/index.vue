<template>
<cimg class="icon-loading rolling" src="./icon-loading.png" />
</template>
<style lang="less">
.icon-loading {
  width: .24rem;
  height: .24rem;
}
</style>
