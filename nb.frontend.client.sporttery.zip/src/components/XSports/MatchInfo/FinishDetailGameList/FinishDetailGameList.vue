<template>
  <div
    v-if="matchInfo.isSettled === false"
    class="x-detail-waitsettle"
  >
    <icon-report />
    <p>该比赛还未结算完成</p>
  </div>
  <div
    v-else
    class="x-detail-game-list"
  >
    <finish-game-item
      v-for="game in matchInfo.scoreGame"
      :key="game.gameID"
      :game="game"
      :match="matchInfo"
      :expanded.sync="game.expanded"
    />
  </div>
</template>
<script>
import IconReport from '@/components/MatchDetail/icons/IconReport';
import FinishGameItem from './FinishGameItem';

export default {
  props: {
    matchInfo: {},
  },
  components: {
    IconReport,
    FinishGameItem,
  },
};
</script>
<style lang="less">
.x-detail-waitsettle {
  margin: 15px;
  text-align: center;
  padding: .2rem;
  background: #fff;
  svg, p {
    opacity: .33;
  }
  p {
    color: #000;
    margin-top: .1rem;
    // opacity: .7;
  }
}
.x-detail-game-list {
  padding: .1rem .1rem 0;
}
</style>
