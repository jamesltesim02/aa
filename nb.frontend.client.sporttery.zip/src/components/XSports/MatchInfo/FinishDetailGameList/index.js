import FinishDetailGameList from './FinishDetailGameList';

export default FinishDetailGameList;
