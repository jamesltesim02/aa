<template>
  <svg v-bind="attrs" class="like-input-clear" xmlns="http://www.w3.org/2000/svg" version="1.1">
    <g stroke="none" class="like-input-clear" stroke-width="1" fill="none" fill-rule="evenodd">
      <g class="like-input-clear" transform="translate(-283, -130)" :fill="fill" fill-rule="nonzero">
        <g class="like-input-clear" transform="translate(283, 130)">
          <path class="like-input-clear" :d="data"></path>
        </g>
      </g>
    </g>
  </svg>
</template>

<script>
export default {
  inheritAttrs: false,
  name: 'BetInputClose',
  props: {
    size: String,
    color: String,
  },
  computed: {
    height() {
      const size = this.size || '0.17';
      const arr = size.match(/(\d+(\.\d+)?)/);
      return +(arr ? arr[1] : '0.17');
    },
    width() {
      return this.height;
    },
    fill() {
      return this.color || '#E8E6E8';
    },
    attrs() {
      return {
        width: `${this.width}rem`,
        height: `${this.height}rem`,
        viewBox: '0 0 17 17',
        style: { width: `${this.width}rem`, height: `${this.height}rem` },
      };
    },
    data() {
      let dt = 'M8.50013333,0 C3.8056355,0 0,3.80555591 0,8.50002222 C0,13.1943996 3.8056355,17 8.50013333,17 C13.1943645,17 ';
      dt += '17,13.1944219 17,8.50002222 C17,3.80557815 13.1943645,0 8.50013333,0 Z M12.0896474,12.0826173 C12.089514,12.0827728 ';
      dt += '12.0893807,12.0829061 12.0892252,12.0830395 C11.852927,12.3193327 11.4698147,12.3195771 11.2332055,12.0834172 ';
      dt += 'L8.50124437,9.35642396 L5.77417187,12.0886168 C5.77401633,12.0887501 5.773883,12.0889279 5.77374967,12.0890168 ';
      dt += 'C5.53742932,12.3253322 5.15433924,12.3255767 4.91775223,12.089439 C4.68074302,11.8528569 4.68034305,11.4694415 ';
      dt += '4.91661895,11.2327262 L7.64371369,8.50053332 L4.91141925,5.77345119 C4.67472113,5.537158 4.67432116,5.15374261 ';
      dt += '4.91059708,4.91702724 C4.91075262,4.91689391 4.91088595,4.91673837 4.91101928,4.91660505 C5.14700633,4.68062294 ';
      dt += '5.53014084,4.68040073 5.76672785,4.91653838 L8.49897786,7.64357609 L11.2258059,4.91131658 C11.2259615,4.91118325 ';
      dt += '11.2260948,4.91102771 11.2262059,4.9109166 C11.4625263,4.67460119 11.8456386,4.67437899 12.0825367,4.91080549 ';
      dt += 'C12.3192792,5.14707647 12.3195903,5.53051407 12.0833589,5.76722943 L9.35624191,8.49946673 L12.0885363,11.2265044 ';
      dt += 'C12.3252344,11.4627976 12.3256122,11.8462574 12.0896474,12.0826173 Z';
      return dt;
    },
  },
};
</script>
