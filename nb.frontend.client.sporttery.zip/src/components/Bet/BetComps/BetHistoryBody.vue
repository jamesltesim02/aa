<template>
  <transition name="history">
    <div :class="`nb-history-body${/^3$/.test(bettingMode) ? '-mix' : ''}`" v-if="data.show">
      <div class="nb-history-body-box">
        <div class="history-body-status flex-start" v-if="!/^3$/.test(bettingMode)" >
          <v-touch class="body-status-cash flex-center" v-if="data.cashObj && data.cashout && data.cash"
          :style="{ background: btnColor, boxShadow: `0 .02rem .06rem 0 ${btnColor}69` }" @tap="eFun">
            <div class="status-cash-text flex-start">{{$t('pageBet.earlyCash')}}</div>
            <div class="status-cash-num flex-center">{{changeCash(data.cash)}}</div>
          </v-touch>
          <div class="body-status-win-lose flex-start" v-else-if="/^[389]$/.test(data.wst)">
            <div class="body-status-win flex-center" v-if="/9/.test(data.wst) && data.x.rtn > data.x.amt" :style="winStyle">
              {{$t('pageBet.earlyCash')}}
            </div>
            <div class="body-status-lose flex-center" v-else-if="/9/.test(data.wst) && data.x.rtn < data.x.amt" :style="loseStyle">
              {{$t('pageBet.earlyCash')}}
            </div>
            <div class="body-status-win flex-center" v-else-if="data.x.rtn > data.x.amt" :style="winStyle">{{$t('pageBet.widNorObj.win100')}}</div>
            <div class="body-status-lose flex-center" v-else-if="data.x.rtn < data.x.amt" :style="loseStyle">{{$t('pageBet.widNorObj.lose100')}}</div>
            <div class="body-status-none flex-center" v-else>{{$t('pageBet.widNorObj.win0')}}</div>
          </div>
          <div class="body-status-cancel flex-center" v-else-if="/^[04567]$/.test(data.wst)">
            {{$t('pageBet.betFail')}}
          </div>
        </div>
        <div :class="moneyClass" class="flex-center-col" v-if="!/^3$/.test(bettingMode)" >
          <div class="body-money-bet flex-end">{{$t('pageBet.moneyBet')}}{{changeType(data.x.amt)}}</div>
          <div class="body-money-rtn-win flex-end" v-if="data.x.rtn >= data.x.amt" :style="{ color: winColor }">
            {{$t(`pageBet.${getRtnStr()}`)}}{{changeType(data.x.rtn)}}
          </div>
          <div class="body-money-rtn-lose flex-end" v-else :style="{ color: loseColor }">
            {{$t(`pageBet.${getRtnStr()}`)}}{{changeType(data.x.rtn)}}
          </div>
        </div>
        <div class="nb-history-option-show-box" :style="optStyle" >
          <div v-for="(v, k) in data.opts" :key="k">
            <bet-history-option :data="v" :isSingle="isSingle" />
            <div class="history-body-short" v-if="!isSingle && k < data.opts.length - 1"></div>
            <div class="history-body-long" v-if="!isSingle && k >= data.opts.length - 1"></div>
          </div>
          <div class="history-body-status-mix flex-start" v-if="/^3$/.test(bettingMode)" >
            <v-touch class="body-status-cash flex-center" v-if="data.cashObj && data.cashout && data.cash" :style="{ background: btnColor }" @tap="eFun">
              <div class="status-cash-text flex-start">{{$t('pageBet.earlyCash')}}</div>
              <div class="status-cash-num flex-center">{{changeCash(data.cash)}}</div>
            </v-touch>
            <div class="body-status-win-lose flex-start" v-else-if="/^[389]$/.test(data.wst)">
              <div class="body-status-win-early-mix flex-center" v-if="/9/.test(data.wst) && data.x.rtn > data.x.amt" :style="winStyle">
                {{$t('pageBet.earlyCash')}}
              </div>
              <div class="body-status-lose-early-mix flex-center" v-else-if="/9/.test(data.wst) && data.x.rtn < data.x.amt" :style="loseMixStyle">
                {{$t('pageBet.earlyCash')}}
              </div>
              <div class="body-status-win-mix flex-center" v-else-if="data.x.rtn > data.x.amt"><bet-mix-win-lose /></div>
              <div class="body-status-lose-mix flex-center" v-else-if="data.x.rtn < data.x.amt"><bet-mix-win-lose lose /></div>
              <div class="body-status-none flex-center" v-else>{{$t('pageBet.widMixObj.win0')}}</div>
            </div>
            <div class="body-status-cancel flex-center" v-else-if="/^[04567]$/.test(data.wst)">
              {{$t('pageBet.betFail')}}
            </div>
          </div>
        </div>
      </div>
      <div class="history-body-mult-box" v-if="!isSingle">
        <v-touch class="history-body-mult" v-for="(v, k) in data.bets" :key="k" @tap="changeFun(v)">
          <div :class="`body-mult-item${/^3$/.test(bettingMode) ? '-mix' : ''} flex-between`">
            <div class="body-mult-item-box flex-start" v-if="!/^3$/.test(bettingMode)" >
              <span class="mult-item-title">{{getMultName(v.num, v.fld)}}</span>
              <span class="mult-item-count" :style="{ color: oddsColor }">{{v.cnt}} {{$t('pageBet.bets')}}</span>
            </div>
            <div class="body-mult-item-box flex-start" v-else >
              <span class="mult-item-title-mix">{{getMultName(v.num, v.fld)}}</span>
              <span class="mult-item-count-mix flex-center">{{v.cnt}}</span>
            </div>
            <div class="body-mult-odds-box flex-start" v-if="v.detail && !/^3$/.test(bettingMode)" >
              <span class="body-mult-odds-at">@</span>
              <span class="body-mult-odds-txt">{{changeType(v.odv, true, 3)}}</span>
            </div>
            <bet-history-body-ani :flag="v.detail" :txt="$t('pageBet.eachBet')"
            :num="changeType(v.tamt / (v.cnt || 1), true)" />
          </div>
          <bet-history-list :data="data" :item="v" />
          <div class="history-body-money-item flex-between" v-if="v.detail && data.bets.length > 1" >
            <div class="body-money-bet flex-start" >
              <span class="body-money-mix-txt flex-center">{{$t('pageBet.betMoney')}}</span>
              <span class="body-money-mix-num flex-center" :style="{ color: oddsColor }">{{changeType(v.tamt, true)}}</span>
            </div>
            <div class="body-money-rtn-win flex-end" >
              <span class="body-money-mix-txt flex-center">{{$t(`pageBet.${getRtnStr()}`)}}</span>
              <span class="body-money-mix-num flex-center" :style="{ color: v.win >= 0 || /^3$/.test(bettingMode) ? winColor : loseColor }">
                {{changeType(/^[389]$/.test(data.wst) ? v.win + v.tamt : v.mxp, true)}}
              </span>
            </div>
          </div>
        </v-touch>
      </div>
      <div :class="`history-body-slip-box${isSingle ? '-s' : ''}`" v-if="/^3$/.test(bettingMode)" >
        <div class="history-body-slip-mix-box" v-if="open" >
          <div class="history-body-slip-mix flex-start">
            <span class="history-body-slip-target flex-start copy-target">{{$t('pageBet.slipNum')}}{{data.mstid}}</span>
            <span class="history-body-slip-alert copy-alert">{{$t('pageBet.slipAlt')}}</span>
            <button class="history-body-slip-button flex-center copy-flag">{{$t('pageBet.slipBtn')}}</button>
          </div>
          <div class="history-body-slip-mix flex-start">
            <span class="history-body-slip-text">{{$t('pageBet.betTime')}}</span>
            <span class="history-body-slip-time">{{data.time}}</span>
          </div>
        </div>
        <div class="history-body-money-mix flex-between" >
          <div class="body-money-bet flex-start" >
            <span class="body-money-mix-txt flex-center">{{$t('pageBet.betMoney')}}</span>
            <span class="body-money-mix-num flex-center" :style="{ color: oddsColor }">{{changeType(data.x.amt, true)}}</span>
          </div>
          <div class="body-money-rtn-win flex-end" >
            <span class="body-money-mix-txt flex-center">{{$t(`pageBet.${getRtnStr()}`)}}</span>
            <span class="body-money-mix-num flex-center" :style="{ color: winColor }">
              {{changeType(data.x.rtn, true)}}
            </span>
          </div>
        </div>
        <v-touch class="body-toggle-box flex-center" @tap="toggleWid">
          <span class="body-toggle-box-txt">{{$t(`pageBet.wid${open ? 'Close' : 'Open'}`)}}</span>
          <bet-arrow-box class="body-toggle-box-arrow" :type="open ? 'up' : 'down'" size="0.07" />
        </v-touch>
      </div>
      <div class="history-body-slip flex-start" v-else >
        <span class="history-body-slip-target flex-start copy-target">{{$t('pageBet.slipNum')}}{{data.mstid}}</span>
        <span class="history-body-slip-alert copy-alert">{{$t('pageBet.slipAlt')}}</span>
        <button class="history-body-slip-button flex-center copy-flag">{{$t('pageBet.slipBtn')}}</button>
      </div>
    </div>
  </transition>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
import { changeNumType } from '@/utils/betUtils';
import BetArrowBox from '@/components/Bet/BetComps/BetArrowBox';
import BetMixWinLose from '@/components/Bet/BetComps/BetMixWinLose';
import BetHistoryList from '@/components/Bet/BetComps/BetHistoryList';
import BetHistoryOption from '@/components/Bet/BetComps/BetHistoryOption';
import BetHistoryBodyAni from '@/components/Bet/BetComps/BetHistoryBodyAni';

export default {
  inheritAttrs: false,
  name: 'BetHistoryBody',
  data() {
    return { open: false };
  },
  props: { data: Object },
  computed: {
    ...mapState('app', ['theme', 'bettingMode']),
    isSingle() {
      return `${this.data.title}` === `${this.$t('pageBet.sinBet')}`;
    },
    optStyle() {
      return /^3$/.test(this.bettingMode) ? { paddingTop: '.04rem' } : { };
    },
    moneyClass() {
      return `history-body-money-${this.isSingle ? 'single' : 'multiple'}`;
    },
    oddsColor() {
      const pSet = window.NBConfig.PORTAL_SETTING;
      if (/^black$/i.test(this.theme)) {
        return pSet && pSet.BLACK_OPTION_COLOR ? pSet.BLACK_OPTION_COLOR : '#ff5353';
      }
      if (/^blue$/i.test(this.theme)) {
        return pSet && pSet.BLUE_OPTION_COLOR ? pSet.BLUE_OPTION_COLOR : '#53fffd';
      }
      return pSet && pSet.WHITE_OPTION_COLOR ? pSet.WHITE_OPTION_COLOR : '#ff5353';
    },
    btnColor() {
      const pSet = window.NBConfig.PORTAL_SETTING;
      if (/^black$/i.test(this.theme)) {
        return pSet && pSet.BLACK_BOTTON_BACKGROUND ? pSet.BLACK_BOTTON_BACKGROUND : '#ff5353';
      }
      if (/^blue$/i.test(this.theme)) {
        return pSet && pSet.BLUE_BOTTON_BACKGROUND ? pSet.BLUE_BOTTON_BACKGROUND : '#00b5b3';
      }
      return pSet && pSet.WHITE_BOTTON_BACKGROUND ? pSet.WHITE_BOTTON_BACKGROUND : '#ff5353';
    },
    winColor() {
      const pSet = window.NBConfig.PORTAL_SETTING;
      if (/^black$/i.test(this.theme)) {
        return pSet && pSet.BLACK_BET_HIS_WIN_COLOR ? pSet.BLACK_BET_HIS_WIN_COLOR : '#ff5353';
      }
      if (/^blue$/i.test(this.theme)) {
        return pSet && pSet.BLUE_BET_HIS_WIN_COLOR ? pSet.BLUE_BET_HIS_WIN_COLOR : '#53fffd';
      }
      return pSet && pSet.WHITE_BET_HIS_WIN_COLOR ? pSet.WHITE_BET_HIS_WIN_COLOR : '#ff5353';
    },
    winStyle() {
      return { border: `.01rem solid ${this.winColor}`, color: this.winColor };
    },
    loseColor() {
      const pSet = window.NBConfig.PORTAL_SETTING;
      if (/^black$/i.test(this.theme)) {
        return pSet && pSet.BLACK_BET_HIS_LOSE_COLOR ? pSet.BLACK_BET_HIS_LOSE_COLOR : '#428723';
      }
      if (/^blue$/i.test(this.theme)) {
        return pSet && pSet.BLUE_BET_HIS_LOSE_COLOR ? pSet.BLUE_BET_HIS_LOSE_COLOR : '#909090';
      }
      return pSet && pSet.WHITE_BET_HIS_LOSE_COLOR ? pSet.WHITE_BET_HIS_LOSE_COLOR : '#428723';
    },
    loseStyle() {
      return { border: `.01rem solid ${this.loseColor}`, color: this.loseColor };
    },
    loseMixStyle() {
      let colorStr = /black/i.test(this.theme) ? '#909090' : '#bababa';
      colorStr = /blue/i.test(this.theme) ? '#909090' : colorStr;
      return { border: `.01rem solid ${colorStr}`, color: colorStr };
    },
  },
  components: {
    BetArrowBox,
    BetMixWinLose,
    BetHistoryList,
    BetHistoryOption,
    BetHistoryBodyAni,
  },
  methods: {
    ...mapMutations(['changeEarlyStatus']),
    changeType(num, fnum, bit) {
      return changeNumType(num, fnum, bit);
    },
    changeCash(cash) {
      const str = `${this.changeType(cash, cash < 100)}`;
      return cash < 100 ? str : str.replace(',', '');
    },
    changeFun(v) {
      const dt = this.data;
      for (let i = 0; i < dt.bets.length; i += 1) {
        const btIdPass = `${dt.bets[i].btId || ''}` === `${v.btId || ''}`;
        const nPass = `${dt.bets[i].num}_${dt.bets[i].fld || 1}` === `${v.num}_${v.fld || 1}`;
        const cPass = dt.bets[i].btId ? btIdPass : nPass;
        if (cPass) {
          dt.bets[i].detail = !dt.bets[i].detail;
        }
      }
      this.$emit('change', dt);
    },
    getRtnStr() {
      return /^[03456789]$/.test(this.data.wst) ? 'moneyRtn' : 'willRtn';
    },
    toggleWid() {
      this.open = !this.open;
    },
    eFun() {
      this.changeEarlyStatus({ mstid: this.data.mstid, money: this.data.cash });
    },
    getMultName(num, fld) {
      const [lan, nFld] = [this.$t('pageBet.betMoney'), fld || 1];
      const nunStr = !/[a-z]+/i.test(lan) ? '一二三四五六七八九十' : '';
      if (nunStr) {
        const beStr = num < 11 ? '一二三四五六七八九十'.substr(num - 1, 1) : num;
        const afStr = nFld < 11 ? '一二三四五六七八九十'.substr(nFld - 1, 1) : nFld;
        return /^3$/.test(this.bettingMode) ? `${num}串${nFld}` : `${beStr}串${afStr}`;
      }
      return `${num} Folds${fld && fld > 1 ? ` ${fld}` : ''}`;
    },
  },
};
</script>

<style lang="less">
.history-enter-active, .history-leave-active { transition: all 0.15s linear; }
.history-enter, .history-leave-active { transform: scaleY(0); }
.white .nb-history-body { border-top: .01rem solid #ECEBEB; }
.white .nb-history-body, .white .nb-history-body-mix {
  .body-status-cash { .status-cash-text { color: #FFF; } .status-cash-num { color: #FFF; } }
  .body-status-cancel { border: .01rem solid #979797; color: #909090; }
  .body-status-win { box-shadow: 0 .02rem .1rem 0 #fe9a9a; }
  .body-status-lose { box-shadow: 0 .02rem .1rem 0 #8cc871; }
  .body-status-none { color: #bababa; border: .01rem solid #ebe9e9; }
  .body-money-bet { color: #909090; }
  .history-body-short { border-bottom: .01rem solid #F5F5F5; }
  .history-body-long { border-bottom: .01rem solid #ebe9e9; }
  .body-mult-item, .body-mult-item-mix { border-bottom: .01rem solid #ebe9e9; .mult-item-title { color: #909090; } }
  .mult-item-title-mix { color: #2e2f34; }
  .mult-item-count-mix { background: #ecebeb; color: #767477; }
  .body-mult-item-mix { background: #fff; }
  .history-body-money-mix { border-bottom: .01rem solid #ebe9e9; color: #909090; background: #fff; }
  .history-body-money-mix .body-money-bet { border-right: .01rem solid #f5f5f5; }
  .history-body-money-item { border-bottom: .01rem solid #ebe9e9; color: #909090; }
  .body-money-mix-txt { color: #909090; }
  .body-mult-odds-at, .body-mult-odds-txt { color: #666; }
  .history-body-slip { color: #BBB; }
  .history-body-slip-button { background: #bababa; color: #fff; }
  .history-body-slip-box-s { border-top: .01rem solid #ebe9e9; margin-top: .06rem; }
  .body-toggle-box { color: #bababa; }
  .history-body-slip-mix-box { border-bottom: .01rem solid #ebe9e9; }
  .history-body-slip-mix { color: #bababa; }
}
.black .nb-history-body { border-top: .01rem solid #2e2f34; }
.black .nb-history-body, .black .nb-history-body-mix {
  .body-status-cash { .status-cash-text { color: #FFF; } .status-cash-num { color: #FFF; } }
  .body-status-cancel { border: .01rem solid #979797; color: #bababa; }
  .body-status-none { color: #bababa; border: .01rem solid #979797; }
  .body-money-bet { color: #bababa; }
  .history-body-short { border-bottom: .01rem solid #2e2f34; }
  .history-body-long { border-bottom: .01rem solid #2e2f34; }
  .body-mult-item, .body-mult-item-mix { border-bottom: .01rem solid #2e2f34; .mult-item-title { color: #bababa; } }
  .mult-item-title-mix { color: #ecebeb; }
  .mult-item-count-mix { background: #28272d; color: #909090; }
  .body-mult-item-mix { background: #35363c; }
  .history-body-money-mix { border-bottom: .01rem solid #2e2f34; color: #bababa; background: #35363c; }
  .history-body-money-mix .body-money-bet { border-right: .01rem solid #2e2f34; }
  .history-body-money-item { border-bottom: .01rem solid #2e2f34; color: #bababa; }
  .body-money-mix-txt { color: #909090; }
  .body-mult-odds-at, .body-mult-odds-txt { color: #bababa; }
  .history-body-slip { color: #909090; }
  .history-body-slip-button { background: #28272d; color: #716d6d; }
  .history-body-slip-box-s { border-top: .01rem solid #2e2f34; margin-top: .06rem; }
  .body-toggle-box { color: #909090; }
  .history-body-slip-mix-box { border-bottom: .01rem solid #2e2f34; }
  .history-body-slip-mix { color: #909090; }
}
.blue .nb-history-body { border-top: .01rem solid #2e2f34; }
.blue .nb-history-body, .blue .nb-history-body-mix {
  .body-status-cash { .status-cash-text { color: #FFF; } .status-cash-num { color: #FFF; } }
  .body-status-cancel { border: .01rem solid #979797; color: #bababa; }
  .body-status-none { color: #bababa; border: .01rem solid #979797; }
  .body-money-bet { color: #bababa; }
  .history-body-short { border-bottom: .01rem solid #2b2c31; }
  .history-body-long { border-bottom: .01rem solid #2b2c31; }
  .body-mult-item, .body-mult-item-mix { border-bottom: .01rem solid #2e2f34; .mult-item-title { color: #bababa; } }
  .mult-item-title-mix { color: #ecebeb; }
  .mult-item-count-mix { background: #39383e; color: #bababa; }
  .body-mult-item, .body-mult-item-mix { background: #3f3e45; }
  .history-body-money-mix { border-bottom: .01rem solid #2e2f34; color: #bababa; background: linear-gradient(to bottom, #3a393f, #333238); }
  .history-body-money-mix .body-money-bet { border-right: .01rem solid #2e2f34; }
  .history-body-money-item { border-bottom: .01rem solid #2e2f34; color: #bababa; }
  .body-money-mix-txt { color: #909090; }
  .body-mult-odds-at, .body-mult-odds-txt { color: #666666; }
  .history-body-slip { color: #777; }
  .history-body-slip-button { background: #434249; color: #b0b0b0; }
  .history-body-slip-box-s { border-top: .01rem solid #2e2f34; margin-top: .06rem; }
  .body-toggle-box { color: #666666; }
  .history-body-slip-mix-box { border-bottom: .01rem solid #2e2f34; }
  .history-body-slip-mix { color: #777777; }
}
.nb-history-body, .nb-history-body-mix {
  width: 100%;
  .nb-history-body-box {
    width: 100%;
    position: relative;
    .history-body-status { height: .35rem; top: .1rem; .body-status-win-lose { height: .35rem; } }
    .history-body-status-mix { height: .38rem; top: 50%; transform: translateY(-50%); .body-status-win-lose { height: .38rem; } }
    .history-body-status, .history-body-status-mix {
      position: absolute;
      min-width: .4rem;
      right: .12rem;
      z-index: 99999;
      .body-status-cash {
        height: .3rem;
        padding: 0 .08rem;
        border-radius: .06rem;
        .status-cash-text { width: .5rem; font-size: .12rem; }
        .status-cash-num { padding-left: .05rem; min-width: .6rem; font-size: .16rem; }
      }
      .body-status-cancel { width: .6rem; height: .24rem; font-size: .12rem; }
      .body-status-win-lose {
        min-width: .4rem;
        .body-status-win, .body-status-lose, .body-status-win-mix, .body-status-lose-mix, .body-status-win-early-mix, .body-status-lose-early-mix, .body-status-none { min-width: .24rem; height: .24rem; }
        .body-status-win, .body-status-lose, .body-status-win-mix, .body-status-lose-mix { padding: 0 .04rem; border-radius: .12rem; font-size: .14rem; }
        .body-status-win-early-mix, .body-status-lose-early-mix { padding: 0 .04rem; border-radius: .06rem; font-size: .14rem; }
        .body-status-none { padding: 0 .06rem; border-radius: .02rem; font-size: .12rem; }
      }
    }
    .history-body-money-single, .history-body-money-multiple {
      position: absolute;
      min-width: 1.1rem;
      height: .4rem;
      right: .12rem;
      .body-money-bet, .body-money-rtn-win, .body-money-rtn-lose { width: 100%; height: 50%; font-size: .12rem; }
    }
    .history-body-money-single { bottom: -0.24rem; }
    .history-body-money-multiple { bottom: .08rem; }
  }
  .nb-history-option-show-box { position: relative; width: 100%; }
  .history-body-short { width: 60%; height: .06rem; }
  .history-body-long { width: 100%; height: .08rem; }
  .history-body-mult {
    width: 100%;
    .body-mult-item, .body-mult-item-mix {
      position: relative;
      width: 100%;
      height: .36rem;
      padding: 0 .12rem;
      .mult-item-title { font-size: .14rem; user-select: none; }
      .mult-item-title-mix { font-size: .16rem; font-weight: 500; user-select: none; }
      .mult-item-count { padding-left: .2rem; font-size: .12rem; user-select: none; }
      .mult-item-count-mix { width: .23rem; height: .23rem; border-radius: 100%; margin-left: .12rem; font-size: .11rem; font-weight: 500; user-select: none; }
    }
  }
  .body-mult-odds-box { position: absolute; width: 80%; height: 100%; left: 0; top: 0; padding-left: 30.5%; }
  .body-mult-odds-at { font-size: .14rem; padding-right: .01rem; font-family: PingFangTC; }
  .body-mult-odds-txt { font-size: .14rem; }
  .history-body-money-item { width: 100%; height: .3rem; padding: 0 .12rem; font-size: .14rem; .body-money-mix-txt { margin-right: .06rem; font-size: .12rem; } }
  .history-body-slip { width: 100%; height: .18rem; margin: .06rem 0; padding: 0 .12rem; font-size: .11rem; }
  .history-body-slip-alert { display: none; }
  .history-body-slip-button { width: .34rem; height: .17rem; margin-left: .1rem; font-size: .11rem; border-radius: .08rem; }
  .history-body-slip-time { flex-grow: 1; }
  .history-body-money-mix { width: 100%; height: .3rem; padding: 0 .25rem; font-size: .14rem; border-bottom-left-radius: .06rem; border-bottom-right-radius: .06rem; }
  .history-body-money-mix { .body-money-bet, .body-money-rtn-win { width: 100%; height: 95%; } }
  .body-money-mix-txt { margin-right: .06rem; font-size: .12rem; }
  .body-money-mix-num { font-size: .14rem; }
  .body-toggle-box { width: 100%; height: .26rem; font-size: .12rem; }
  .history-body-slip-mix-box { width: 100%; padding: .05rem .12rem; }
  .history-body-slip-mix { width: 100%; height: .22rem; font-size: .11rem; }
  .history-body-slip-text { padding-right: .06rem; }
}
.horizontal .nb-history-body {
  .status-cash-text { width: .55rem !important; }
  .body-item-legal { max-width: 1.2rem !important; }
}
</style>
