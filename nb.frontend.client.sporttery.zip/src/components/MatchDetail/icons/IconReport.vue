<template>
  <svg
    class="icon-report"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    enable-background="new 0 0 24 24"
  >
    <path
      d="M10.8 17.8c-.3 0-.6-.2-.7-.4l-2.5-4.9-3.1 1.9c-.4.2-.9.1-1.1-.3-.2-.4-.1-.9.3-1.1l3.8-2.4c.2-.1.4-.2.6-.1.2.1.4.2.5.4l2.3 4.5 3.4-5.3c.1-.2.4-.4.6-.4.3 0 .5.1.7.3l1.7 2.3 5.2-10.3c.2-.4.7-.5 1.1-.4.4.2.6.7.4 1.1l-5.8 11.4c-.1.2-.4.4-.6.4-.3 0-.5-.1-.7-.3l-1.9-2.2-3.5 5.5c-.2.2-.4.3-.7.3M22.9 22.4h-22.1c-.5 0-.8-.4-.8-.8v-19.2c0-.4.3-.7.8-.7s.7.3.7.7v18.5h21.4c.4 0 .8.3.8.8 0 .4-.3.7-.8.7"
    ></path>
  </svg>
</template>
<style lang="less">
.icon-report {
  opacity: .54;
  overflow: hidden;
  height: 88px;
  width: 88px;
  fill: currentColor;
  margin: 0;
  padding: 0;
  border: 0;
  font-size: inherit;
  font: inherit;
  vertical-align: inherit;
  text-align: inherit;
  border-color: inherit;
  color: inherit;
  text-shadow: none;
  text-indent: 0;
  * {
    -webkit-text-stroke: 1px transparent;
    box-sizing: border-box;
    position: static;
    min-height: auto;
    z-index: auto;
    transform-origin: 0px 0px;
  }
}
</style>
