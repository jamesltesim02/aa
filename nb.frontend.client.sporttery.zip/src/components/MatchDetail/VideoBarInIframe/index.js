import VideoBarInIframe from './VideoBarInIframe';

export default VideoBarInIframe;
