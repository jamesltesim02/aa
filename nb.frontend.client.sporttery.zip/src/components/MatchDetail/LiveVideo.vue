<template>
  <div>live video</div>
</template>
<script>
export default {
};
</script>

