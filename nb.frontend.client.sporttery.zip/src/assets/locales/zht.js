export default {
  msg1: '妳好!',
  msg2: '我是繁軆msg2.',
  msg3: '我是繁軆msg3',
};
