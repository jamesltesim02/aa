import AdExample from './AdExample';

export default AdExample;
