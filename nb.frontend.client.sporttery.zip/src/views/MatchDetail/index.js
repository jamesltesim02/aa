import MatchDetail from './MatchDetail';

export default MatchDetail;
