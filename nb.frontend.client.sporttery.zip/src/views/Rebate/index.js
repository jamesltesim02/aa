import Rebate from './Rebate';

export default Rebate;
