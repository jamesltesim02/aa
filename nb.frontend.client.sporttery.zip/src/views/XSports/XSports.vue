<template>
  <list-page
    class="xsports"
    @scrollBottom="scrollToNextPage"
  >
    <div slot="header">
      <nav-bar>
        <icon-logo slot="content" />
        <menu-button />
      </nav-bar>
      <filter-bar
        :value="state"
        @change="changeState"
      />
      <date-picker
        v-if="[0, 3].includes(state)"
        v-model="queryDate"
        :expand="dayCountText"
        :rangeTo="state === 0 ? daysCount : -30"
      />
    </div>
    <match-list
      v-if="state !== 3"
      ref="listComp"
      :state="state"
      :query-date="state === 0 ? queryDate : ''"
    />
    <finished-list
      v-else
      :query-date="queryDate"
    />
  </list-page>
</template>
<script>
import { mapState } from 'vuex';
import { findmatchscount } from '@/api/pull';
import NavBar from '@/components/common/NavBar';
import MenuButton from '@/components/XSports/MenuButton';
import FilterBar from '@/components/XSports/FilterBar';
import MatchList from '@/components/XSports/MatchList';
import FinishedList from '@/components/XSports/FinishedList';
import IconLogo from './icons/IconLogo';
import DatePicker from '@/components/XSports/FinishedList/DatePicker';

export default {
  props: {
    state: {
      type: Number,
      default: 1,
    },
  },
  data() {
    return {
      queryDate: new Date(),
      countObj: null,
      countByDay: null,
    };
  },
  computed: {
    ...mapState('xsports', ['activeSports']),
    daysCount() {
      if (this.countObj && this.countObj.lastMatchDay) {
        let str = `${this.countObj.lastMatchDay}`;
        str = `${str.slice(0, 4)}/${str.slice(4, 6)}/${str.slice(-2)} 23:59:59`;
        const deltaMiniSec = new Date(str).getTime() - new Date().getTime();
        return parseInt(Math.abs(deltaMiniSec) / 86400000, 10);
      }
      return 30;
    },
    dayCountText() {
      if (this.state !== 0 || !this.queryDate || !this.countByDay) {
        return '';
      }
      const dayKey = this.$options.filters.dateFormat(this.queryDate, 'yyyyMMdd');

      if (!this.countByDay[dayKey]) {
        return '';
      }

      return `&nbsp; 共${this.countByDay[dayKey]}场`;
    },
  },
  watch: {
    state() {
      this.queryDate = new Date();
    },
  },
  components: {
    MenuButton,
    NavBar,
    FilterBar,
    MatchList,
    FinishedList,
    IconLogo,
    DatePicker,
  },
  created() {
    this.queryCountByDate();
  },
  methods: {
    scrollToNextPage() {
      if (this.state !== 3 && this.$refs.listComp) {
        this.$refs.listComp.nextPage();
      }
    },
    changeState(v) {
      if (typeof v === 'number') {
        this.$router.replace(`/xsports/${v}`);
        return;
      }
      if (typeof v === 'object') {
        this.countObj = v.counts || null;
        this.$router.replace(`/xsports/${v.state || 0}`);
      }
    },
    /**
     * 查询每天的比赛场数
     */
    async queryCountByDate() {
      const countByDay = {};
      const countResult = await findmatchscount({
        sportIds: this.activeSports,
      });
      countResult.forEach((c) => { countByDay[+c.matchDay] = c.num; });
      this.countByDay = countByDay;
    },
  },
};
</script>
<style lang="less">
.xsports .nav-bar {
  border-bottom: solid 1px #ecebeb;
  z-index: 2;
  .nav-content {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }
}
.blue .xsports .nav-bar {
  border-bottom: solid 1px #2e2f34;
}
</style>
