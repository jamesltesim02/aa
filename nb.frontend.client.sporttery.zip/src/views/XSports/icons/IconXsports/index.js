import IconXsports from './IconXsports';

export default IconXsports;
