import XSports from './XSports';

export default XSports;
