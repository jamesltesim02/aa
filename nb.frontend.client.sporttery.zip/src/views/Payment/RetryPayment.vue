<template>
  <div></div>
</template>
<script>
export default {
  created() {
    this.$router.replace('/payment');
  },
};
</script>
