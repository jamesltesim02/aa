import { openInBrowser } from './AppUtils';
import { live800Url } from '../AgPortalUtils';

/**
 * 打开在线客服
 *
 * @param {object} context
 *    调用时的上下文
 */
export const toCustomerService = (context) => {
  const pSet = window.NBConfig.PORTAL_SETTING;
  if (pSet && pSet.SERVICE_CENTER_URL) {
    let url = pSet.SERVICE_CENTER_URL;
    url = `${url}${/\?/.test(url) ? '&' : '?'}from=NB&backUrl=`;
    openInBrowser(`${url}${encodeURIComponent(window.location.href)}`);
  } else {
    openInBrowser(live800Url(context));
  }
};

/**
 * 打开存款提交页面
 *
 * @param {object} params
 *     存款订单参数
 */
export const openToPayment = (params) => {
  const {
    protocol,
    host,
  } = window.location;

  const orderInfo = encodeURIComponent(JSON.stringify(params));
  const portalUrl = `${protocol}//${host}/payment-forward.html?${orderInfo}`;

  openInBrowser(portalUrl);
};
