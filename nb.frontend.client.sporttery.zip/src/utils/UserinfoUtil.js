import store from '@/store';
import { agLogout } from '@/api/portalAgyy';

export const getUserinfo = () => store.state.app.userinfo || {};

export const isLoged = () => store.state.app.isLoged;

export const getToken = () => getUserinfo().token || undefined;

export const logout = () => {
  store.commit('app/setUserinfo', null);
  window.location = '/#/';
};

export const logoutWithApi = async () => {
  try {
    await agLogout();
    logout();
  } catch (e) {
    console.warn(e);
  }
};
