import { loadFromStorage } from '@/utils/StorageUtil';
import { StorageKey } from '@/config/constants';

/**
 * FONT_ID对照
 * 亚游: 102001011JIaThBA
 * 凯时: 1000610117Qe1Gj0
 * 酷游: 102061011cYgTGB2 (凯发电游)
 * 和记: 1010410116Ea5Hq7
 * 永乐: 101031011k3Lx9Tf
 */
const { FRONT_ID } = window.NBConfig;

/**
 * 转到商户页面
 *
 * @param {string} url
 *    商户页面地址
 */
export const toPortalUrl = (url) => {
  const {
    protocol,
    host,
    hash,
  } = window.location;
  const symbol = /.+?#.+?\?.*/.test(url) ? '&' : '?';

  const params = {
    nborigin: encodeURIComponent(`${protocol}//${host}/${hash.split('?')[0] || ''}`),
    memberToken: loadFromStorage(StorageKey.PORTAL_MEMBER_TOKEN, ''),
    loginName: loadFromStorage(StorageKey.PORTAL_LOGIN_NAME, ''),
  };

  if (['102061011cYgTGB2', '1000610117Qe1Gj0'].includes(FRONT_ID)) {
    params.c = host;
    params.palcode = loadFromStorage(StorageKey.PORTAL_PALCODE, '');
  }

  const paramsStr = Object.entries(params)
    .filter(kv => !!kv[1])
    .map(kv => `${kv[0]}=${kv[1]}`)
    .join('&');

  const portalUrl = `${url}${symbol}${paramsStr}`;

  window.location = portalUrl;
};


/**
 * 获取转到比赛列表页面的地址
 */
export const getMatchsPageUrl = () => {
  if (FRONT_ID === '102061011cYgTGB2') {
    return '/home';
  }

  return '/matchs/0/10';
};
