export default () => {
  const el = document.createElement('script');
  el.src = 'https://hm.baidu.com/hm.js?47673dea2a385559520965fd7b1c6f75';
  document.body.appendChild(el);
};
