import Vue from 'vue';
import router from '@/router';
import appConfig from '@/config/business.config';
import { StorageKey, AppModes } from '@/config/constants';
import { loadFromStorage, saveToStorage, getCacheData } from '@/utils/StorageUtil';
import { connect, reconnect, regpush } from '@/utils/PushUtil';
// import { getAppInit } from '@/api/portalAgyy';
import { finddomaininfo } from '@/api/pull';
import { getBetBalance } from '@/api/bet';
import getParameter from '@/utils/getParameter';
import { toPortalUrl, getMatchsPageUrl } from '@/utils/PortalUtils';
import store from '@/store';

const {
  location,
  history,
  NBConfig: {
    FRONT_ID,
    APP_MODE,
    HOME_IS_MATCH_LIST,
    PORTAL_SETTING: pSet,
  },
} = window;

/**
 * AG加密Key和注册验证方式初始化
 */
// const AGKeyAndTypeInit = async () => {
//   const data = await getAppInit();
//   if (data && data.cryptoKey) {
//     store.commit('app/setCryptKey', data.cryptoKey);
//   }
//   if (data && data.registerVerificationType) {
//     store.commit('app/setAGRegType', data.registerVerificationType);
//   }
// };


/**
 * 商户接入参数配置初始化
const casinoInfoInit = () => {
  let frontId = getParameter('frontId');

  // 如果不是seamless,则直接从配置文件中获取frontId并不做其他初始化
  store.commit('app/updateFrontId', window.NBConfig.FRONT_ID);

  // 用户token
  const token = getParameter('token');
  if (token) {
    store.commit('app/setUserinfo', { token });
  }

  const memberToken = getParameter('memberToken');
  if (memberToken) {
    saveToStorage(StorageKey.PORTAL_MEMBER_TOKEN, memberToken);
  }

  const palcode = getParameter('palcode');
  if (palcode) {
    saveToStorage(StorageKey.PORTAL_PALCODE, palcode);
  }

  const fromURL = getParameter('fromURL');
  if (fromURL) {
    saveToStorage(StorageKey.FROM_URL_KEY, fromURL);
  }

  history.replaceState(
    null,
    null,
    `${location.protocol}//${location.host}/${location.hash}`,
  );
};
*/

/**
 * 商户配置初始化
 */
const portalInit = async () => {
  let frontId = getParameter('frontId');
  if (frontId) {
    saveToStorage(StorageKey.FRONT_ID_KEY, frontId);
  } else {
    frontId = loadFromStorage(StorageKey.FRONT_ID_KEY) || window.NBConfig.FRONT_ID;
  }
  store.commit('app/updateFrontId', frontId);

  const loginName = getParameter('loginName');
  if (loginName) {
    saveToStorage(StorageKey.PORTAL_LOGIN_NAME, loginName);
  }
  // 游戏token
  const token = getParameter('token');
  if (token) {
    store.commit('app/setUserinfo', {
      token,
      memberAccount: loginName,
    });
  }
  const memberToken = getParameter('memberToken');
  if (memberToken) {
    saveToStorage(StorageKey.PORTAL_MEMBER_TOKEN, memberToken);
  }

  const portalInfo = await getCacheData(
    StorageKey.PORTAL_SETTING_KEY,
    appConfig.portalCacheTime,
    finddomaininfo,
  );

  // 无法查询到商户配置
  if (portalInfo) {
    // 更新商户配置信息
    store.commit('app/updatePortalInfo', portalInfo);
  }


  history.replaceState(
    null,
    null,
    `${location.protocol}//${location.host}/${location.hash}`,
  );
};

/**
 * 消息推送初始化
 */
const pushInit = () => {
  // 启动push连接
  connect();
  Vue.prototype.$regpush = regpush;

  window.onfocus = () => {
    reconnect();
  };
};

/**
 * 连接登录检查
 */
const routerLoginCheck = () => {
  router.beforeEach((to, from, next) => {
    store.commit('app/updateToast', '');
    store.commit('app/updateLastLocation', from);
    store.commit('payment/updatePopInfo', null);

    // seamless模式，且进了非展示页，跳转至足球页，页面id及说明详见@/router/index.js
    const noShowPage = /^(10\d|[29]\d{2}|800|8[1-9]\d)$/.test(to.meta.index);
    if (AppModes.SEAMLESS === APP_MODE && noShowPage) {
      next({ path: getMatchsPageUrl() });
      return;
    }
    // 个人中心设置了跳转地址，则个人中心相关页面跳转到首页
    const api = pSet && pSet.LOGIN_API ? pSet.LOGIN_API : null;
    const pass = api && api.URI && /^(get|post)$/i.test(api.METHOD);
    const userReg = new RegExp(`^(10[0${pass ? '' : '1'}2]|8[1-9]\\d)$`);
    if (pSet && pSet.USER_CENTER_URL && userReg.test(to.meta.index)) {
      next({ path: '/' });
      return;
    }
    // 4XX: 投注单，投注记录类页面, 5XX: 我的，个人中心，设置等相关页面，设置页面501-509允许不登录进入
    const isPerson = /^(4\d{2}|800|8[1-9]\d)$/.test(to.meta.index);
    // 是否登录
    const isLogin = store.state.app.isLoged;

    if (isLogin && /^10[12]$/.test(to.meta.index)) {
      next({ path: '/' });
    }

    if (isLogin || !isPerson) {
      next();
      if (/^2\d{2}$/.test(to.meta.index) && !HOME_IS_MATCH_LIST) {
        store.commit('clearBetItem');
      }
      return;
    }

    // 如果是Seamless则返回原地址并提示消息
    if (AppModes.SEAMLESS === APP_MODE) {
      next({ path: from.path });
      store.commit('app/updateToast', 'pageBet.notLogin');
      return;
    }

    if (pSet && pSet.LOGIN_PAGE_URL) {
      toPortalUrl(pSet.LOGIN_PAGE_URL);
    } else {
      // 如果是非Seamless则转到login页面
      store.commit('app/updateLastLocation', to);
      next({ path: '/login' });
    }
  });
  let isFirst = true;
  router.afterEach((to, { fullPath }) => {
    if (isFirst) {
      isFirst = false;
      return;
    }
    store.commit('app/setLastPath', fullPath);
  });
};

/**
 * 禁止苹果缩放
 */
const blurInputs = () => {
  setTimeout(() => { document.querySelectorAll('input:focus').forEach(v => v.blur()); }, 100);
};

const disableAppleZoom = () => {
  let lastTouchEnd = 0;
  document.addEventListener('touchstart', (event) => {
    if (event.target.tagName !== 'INPUT') {
      blurInputs();
    }
    if (event.touches.length > 1) {
      event.preventDefault();
    }
  }, { passive: false });
  document.addEventListener('touchmove', blurInputs, { passive: false });
  document.addEventListener('touchend', (event) => {
    const now = new Date().getTime();
    if (now - lastTouchEnd <= 300) {
      event.preventDefault();
    }
    lastTouchEnd = now;
  }, { passive: false });
  document.addEventListener('gesturestart', (event) => {
    event.preventDefault();
  }, { passive: false });
  document.addEventListener('gesturechange', (event) => {
    event.preventDefault();
  }, { passive: false });
};

// 保持session和token的定时任务
const keepPortalSession = () => {
  /**
   * FONT_ID对照
   * 亚游: 102001011JIaThBA (B79)
   * 凯时: 1000610117Qe1Gj0 (A06)
   * 酷游: 102061011cYgTGB2 (B06 凯发电游)
   * 和记: 1010410116Ea5Hq7 (E03)
   * 永乐: 101031011k3Lx9Tf (E04)
   */
  if (FRONT_ID !== '102001011JIaThBA') {
    return;
  }
  // if (APP_MODE !== AppModes.STANDALONE_LITE) {
  //   return;
  // }

  // 保障AG session有效定时任务
  setInterval(() => {
    // 如果未登录,则不用发起更新请求
    if (!store.state.app.isLoged) {
      return;
    }
    // 发起更新用户信息action,目的保持session有效
    store.dispatch('app/agRealodUserinfo');
  }, appConfig.keepPortalSessionTime);

  // 保障AG token有效定时任务
  setInterval(async () => {
    // 如果未登录,则不用发起更新请求
    if (!store.state.app.isLoged) {
      return;
    }

    // 发起查询用户信息调用, 会调用QueryAccount来保持tokne有效
    await getBetBalance();
  }, appConfig.keepPortalTokenTime);
};

export default {
  install() {
    // 现金网接入seamless判断及初始化
    // casinoInfoInit();
    // 如果没有找到frontId则不再继续进行初始化
    // 商户配置初始化
    portalInit();
    // 消息推送初始化
    pushInit();
    // 注册登录检查
    routerLoginCheck();
    // 禁止苹果缩放
    disableAppleZoom();
    // 保持商户session有效
    keepPortalSession();
    // 获取AG配置
    // if (/^3$/.test(APP_MODE) && !(pSet && pSet.USER_CENTER_URL)) {
    //   AGKeyAndTypeInit();
    // }
  },
};
