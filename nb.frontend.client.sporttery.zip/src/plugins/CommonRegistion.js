import Vue from 'vue';

import dateFormat from '@/filters/dateFormat';
import oddsFormat from '@/filters/oddsFormat';
import moneyFormat from '@/filters/moneyFormat';
import banknoFormat from '@/filters/banknoFormat';

import Cimg from '@/components/common/Cimg';
import ExpandTransition from '@/components/common/ExpandTransition';
import RollingText from '@/components/common/RollingText';
import LoadingBar from '@/components/common/LoadingBar';
import ListPage from '@/components/common/ListPage';
import NavBar from '@/components/common/NavBar';

const installFilters = () => {
  // 时间日期格式化
  Vue.filter('dateFormat', (source, pattern) => dateFormat(source, pattern));
  // 赔率显示转换
  Vue.filter('oddsFormat', oddsFormat);
  // 金额格式化
  Vue.filter('moneyFormat', moneyFormat);
  // 银行卡格式化
  Vue.filter('banknoFormat', banknoFormat);
};

const installComponents = () => {
  // cdn图片组件
  Vue.component('cimg', Cimg);
  // 展开收起组件
  Vue.component('expand-transition', ExpandTransition);
  // 文字走马灯组件
  Vue.component('rolling-text', RollingText);
  // loading行
  Vue.component('loading-bar', LoadingBar);
  // 上中下页面结构组件(中间区域可以滑动)
  Vue.component('list-page', ListPage);
  // 导航栏组件
  Vue.component('nav-bar', NavBar);
};

const install = () => {
  installFilters();
  installComponents();
};

export default { install };
